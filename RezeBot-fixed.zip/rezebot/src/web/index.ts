import 'dotenv/config';
import { createWebApp } from './app';
import { getConfig } from '../core/config';

async function main(): Promise<void> {
  const config = getConfig();
  const server = createWebApp();
  await server.listen({ port: config.WEB_PORT });
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
