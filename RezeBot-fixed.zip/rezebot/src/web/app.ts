/**
 * RezeBot — Web Application
 * Express-based web panel, REST API, and Telegram Mini App backend.
 */

import express, { type Express, type Request, type Response, type NextFunction } from 'express';
import helmet from 'helmet';
import cookieParser from 'cookie-parser';
import crypto from 'crypto';
import path from 'path';
import { getConfig } from '../core/config';
import { LoggerProvider } from '../core/logging';
import { featureFlags } from '../core/feature-flags';
import { query } from '../db/pool';
import { createBot } from '../bot/botFactory';
import { webhookCallback } from 'grammy';

const logger = LoggerProvider.get('WebApp');
const __dirname = path.resolve(process.cwd(), 'dist/web');

export interface WebServer {
  app: Express;
  listen: (options: { port: number }) => Promise<{ close: () => Promise<void> }>;
}

interface AuthenticatedRequest extends Request {
  auth?: { userId: number; role: string; chatId?: number };
}

/**
 * Verify Telegram Mini App initData using HMAC-SHA-256.
 * Reference: https://core.telegram.org/bots/webapps#validating-data-received-via-the-mini-app
 */
export function validateInitData(initData: string, botToken: string): { valid: boolean; user?: Record<string, unknown> } {
  try {
    const params = new URLSearchParams(initData);
    const hash = params.get('hash');
    if (!hash) return { valid: false };

    params.delete('hash');
    const dataCheckString = [...params.entries()]
      .map(([k, v]) => `${k}=${v}`)
      .sort()
      .join('\n');

    const secretKey = crypto.createHmac('sha256', 'WebAppData').update(botToken).digest();
    const computedHash = crypto
      .createHmac('sha256', secretKey)
      .update(dataCheckString)
      .digest('hex');

    const valid = crypto.timingSafeEqual(Buffer.from(computedHash), Buffer.from(hash));

    if (!valid) return { valid: false };

    // Check auth_date freshness (24h)
    const authDate = Number(params.get('auth_date') ?? 0);
    if (authDate && Date.now() / 1000 - authDate > 86400) {
      return { valid: false };
    }

    const userRaw = params.get('user');
    const user = userRaw ? JSON.parse(userRaw) : undefined;

    return { valid: true, user };
  } catch (error) {
    logger.error('Failed to validate initData', { error: String(error) });
    return { valid: false };
  }
}

function authMiddleware(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
  const header = req.headers['authorization'];
  const token = header?.startsWith('Bearer ') ? header.slice(7) : null;

  if (!token) {
    res.status(401).json({ error: 'Authentication required' });
    return;
  }

  // Mini App session token: base64(userId:role:chatId:signature)
  try {
    const decoded = Buffer.from(token, 'base64').toString('utf-8');
    const [userIdStr, role, chatIdStr, signature] = decoded.split(':');
    const config = getConfig();
    const expected = crypto
      .createHmac('sha256', config.JWT_SECRET)
      .update(`${userIdStr}:${role}:${chatIdStr}`)
      .digest('hex');

    if (!signature || !crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expected))) {
      res.status(403).json({ error: 'Invalid session' });
      return;
    }

    req.auth = {
      userId: Number(userIdStr),
      role,
      chatId: chatIdStr ? Number(chatIdStr) : undefined,
    };
    next();
  } catch {
    res.status(403).json({ error: 'Invalid or expired token' });
  }
}

export function createWebApp(): WebServer {
  const config = getConfig();
  const app = express();

  app.use(helmet({ contentSecurityPolicy: false }));
  app.use(express.json({ limit: '1mb' }));
  app.use(cookieParser(config.SESSION_SECRET));

  // Telegram webhook. Telegram POSTs every update here. The same bot instance
  // is reused so session/database state is shared across all chats and users.
  if (process.env.WEBHOOK === 'true' || process.env.VERCEL === '1') {
    const bot = createBot();
    app.post('/api/telegram/webhook', (req, res, next) => {
      if (config.WEBHOOK_SECRET) {
        const supplied = req.header('X-Telegram-Bot-Api-Secret-Token');
        if (supplied !== config.WEBHOOK_SECRET) {
          res.status(403).json({ error: 'Forbidden' });
          return;
        }
      }
      return webhookCallback(bot, 'express')(req, res, next);
    });
  }

  // Health endpoints
  app.get('/health', (_req, res) => {
    res.json({ status: 'ok', timestamp: new Date().toISOString(), uptime: process.uptime() });
  });
  app.get('/live', (_req, res) => res.json({ status: 'live' }));
  app.get('/ready', async (_req, res) => {
    try {
      await query('SELECT 1');
      res.json({ status: 'ready' });
    } catch {
      res.status(503).json({ status: 'not_ready' });
    }
  });

  // ── Mini App authentication ──────────────────────────────────
  app.post('/mini-app/auth', (req: Request, res: Response) => {
    const { initData } = req.body as { initData?: string };
    if (!initData) {
      res.status(400).json({ error: 'initData required' });
      return;
    }

    const result = validateInitData(initData, config.BOT_TOKEN);
    if (!result.valid || !result.user) {
      res.status(401).json({ error: 'Invalid initData' });
      return;
    }

    const user = result.user as { id: number; username?: string };
    const role = 'user';
    const signature = crypto
      .createHmac('sha256', config.JWT_SECRET)
      .update(`${user.id}:${role}:`)
      .digest('hex');
    const token = Buffer.from(`${user.id}:${role}:${signature}`).toString('base64');

    res.json({ token, user, role });
  });

  // ── Feature flags ────────────────────────────────────────────
  app.get('/api/features', (_req, res) => {
    res.json(featureFlags.getAllFlags());
  });

  // ── Groups (authenticated) ───────────────────────────────────
  app.get('/api/groups', authMiddleware, async (req: AuthenticatedRequest, res) => {
    try {
      const result = await query(
        'SELECT * FROM chats WHERE type IN (\'group\', \'supergroup\') ORDER BY created_at DESC LIMIT 100'
      );
      res.json(result.rows);
    } catch (error) {
      logger.error('Failed to fetch groups', { error: String(error) });
      res.status(500).json({ error: 'Failed to fetch groups' });
    }
  });

  app.get('/api/groups/:chatId', authMiddleware, async (req: AuthenticatedRequest, res) => {
    try {
      const result = await query('SELECT * FROM chats WHERE id = $1', [req.params.chatId]);
      if (result.rows.length === 0) {
        res.status(404).json({ error: 'Group not found' });
        return;
      }
      res.json(result.rows[0]);
    } catch (error) {
      logger.error('Failed to fetch group', { error: String(error) });
      res.status(500).json({ error: 'Failed to fetch group' });
    }
  });

  // ── Moderation history ───────────────────────────────────────
  app.get('/api/groups/:chatId/moderation', authMiddleware, async (req: AuthenticatedRequest, res) => {
    try {
      const result = await query(
        'SELECT * FROM moderation_actions WHERE chat_id = $1 ORDER BY created_at DESC LIMIT 100',
        [req.params.chatId]
      );
      res.json(result.rows);
    } catch (error) {
      logger.error('Failed to fetch moderation history', { error: String(error) });
      res.status(500).json({ error: 'Failed to fetch moderation history' });
    }
  });

  // ── Analytics ────────────────────────────────────────────────
  app.get('/api/groups/:chatId/analytics', authMiddleware, async (req: AuthenticatedRequest, res) => {
    try {
      const chatId = req.params.chatId;
      const [members, actions, warnings, reports] = await Promise.all([
        query('SELECT COUNT(*)::int AS count FROM chat_members WHERE chat_id = $1', [chatId]),
        query('SELECT COUNT(*)::int AS count FROM moderation_actions WHERE chat_id = $1', [chatId]),
        query('SELECT COUNT(*)::int AS count FROM warnings WHERE chat_id = $1', [chatId]),
        query('SELECT COUNT(*)::int AS count FROM audit_logs WHERE chat_id = $1', [chatId]),
      ]);

      res.json({
        members: members.rows[0].count,
        moderationActions: actions.rows[0].count,
        warnings: warnings.rows[0].count,
        auditEvents: reports.rows[0].count,
        chatId,
      });
    } catch (error) {
      logger.error('Failed to fetch analytics', { error: String(error) });
      res.status(500).json({ error: 'Failed to fetch analytics' });
    }
  });

  // ── Static Mini App / Web Panel ──────────────────────────────
  const publicDir = path.resolve(__dirname, '../../web/public');
  app.use(express.static(publicDir));
  app.get('/mini-app', (_req, res) => {
    res.sendFile(path.join(publicDir, 'mini-app.html'));
  });

  // Error handler
  app.use((err: Error, _req: Request, res: Response, _next: NextFunction) => {
    logger.error('Unhandled web error', { error: err.message });
    res.status(500).json({ error: 'Internal server error' });
  });

  return {
    app,
    listen: async ({ port }) => {
      return new Promise((resolve) => {
        const server = app.listen(port, () => {
          logger.info(`Web server listening on port ${port}`);
          resolve({
            close: () =>
              new Promise<void>((res2, rej) => {
                server.close((err) => (err ? rej(err) : res2()));
              }),
          });
        });
      });
    },
  };
}

export default createWebApp;
