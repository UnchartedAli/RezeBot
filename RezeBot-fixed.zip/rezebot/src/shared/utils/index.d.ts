/**
 * RezeBot — Shared Utilities
 * Common helper functions used across modules.
 */
/**
 * Generate a random token of specified length using crypto-safe random bytes.
 */
export declare function generateToken(length?: number): string;
/**
 * Generate a UUID v4.
 */
export declare function generateUUID(): string;
/**
 * Sleep for the specified number of milliseconds.
 */
export declare function sleep(ms: number): Promise<void>;
/**
 * Retry an async function with exponential backoff.
 */
export declare function retryAsync<T>(fn: () => Promise<T>, maxRetries?: number, delayMs?: number, backoffFactor?: number): Promise<T>;
/**
 * Deep clone an object.
 */
export declare function deepClone<T>(obj: T): T;
/**
 * Check if a value is a valid positive integer.
 */
export declare function isPositiveInteger(value: unknown): value is number;
/**
 * Safe JSON parse.
 */
export declare function safeParseJSON<T = unknown>(str: string): T | null;
/**
 * Format a duration in seconds to a human-readable string (Persian-aware).
 */
export declare function formatDuration(seconds: number): string;
declare const _default: {
    generateToken: typeof generateToken;
    generateUUID: typeof generateUUID;
    sleep: typeof sleep;
    retryAsync: typeof retryAsync;
    deepClone: typeof deepClone;
    isPositiveInteger: typeof isPositiveInteger;
    safeParseJSON: typeof safeParseJSON;
    formatDuration: typeof formatDuration;
};
export default _default;
//# sourceMappingURL=index.d.ts.map