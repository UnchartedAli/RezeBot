"use strict";
/**
 * RezeBot — Shared Utilities
 * Common helper functions used across modules.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateToken = generateToken;
exports.generateUUID = generateUUID;
exports.sleep = sleep;
exports.retryAsync = retryAsync;
exports.deepClone = deepClone;
exports.isPositiveInteger = isPositiveInteger;
exports.safeParseJSON = safeParseJSON;
exports.formatDuration = formatDuration;
/**
 * Generate a random token of specified length using crypto-safe random bytes.
 */
function generateToken(length = 32) {
    const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    const array = new Uint8Array(length);
    crypto.getRandomValues(array);
    return Array.from(array, (i) => chars[i % chars.length]).join('');
}
/**
 * Generate a UUID v4.
 */
function generateUUID() {
    return crypto.randomUUID();
}
/**
 * Sleep for the specified number of milliseconds.
 */
function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
}
/**
 * Retry an async function with exponential backoff.
 */
async function retryAsync(fn, maxRetries = 3, delayMs = 500, backoffFactor = 2) {
    let lastError;
    for (let attempt = 0; attempt <= maxRetries; attempt++) {
        try {
            return await fn();
        }
        catch (error) {
            lastError = error instanceof Error ? error : new Error(String(error));
            if (attempt === maxRetries)
                break;
            const delay = delayMs * Math.pow(backoffFactor, attempt);
            await sleep(delay);
        }
    }
    throw lastError;
}
/**
 * Deep clone an object.
 */
function deepClone(obj) {
    if (obj === null || typeof obj !== 'object')
        return obj;
    if (obj instanceof Date)
        return new Date(obj.getTime());
    if (obj instanceof Array)
        return obj.map((item) => deepClone(item));
    if (typeof obj === 'object') {
        const cloned = {};
        for (const key in obj) {
            cloned[key] = deepClone(obj[key]);
        }
        return cloned;
    }
    return obj;
}
/**
 * Check if a value is a valid positive integer.
 */
function isPositiveInteger(value) {
    return typeof value === 'number' && Number.isInteger(value) && value > 0;
}
/**
 * Safe JSON parse.
 */
function safeParseJSON(str) {
    try {
        return JSON.parse(str);
    }
    catch {
        return null;
    }
}
/**
 * Format a duration in seconds to a human-readable string (Persian-aware).
 */
function formatDuration(seconds) {
    if (seconds < 60)
        return `${seconds} ثانیه`;
    if (seconds < 3600)
        return `${Math.floor(seconds / 60)} دقیقه`;
    if (seconds < 86400)
        return `${Math.floor(seconds / 3600)} ساعت`;
    return `${Math.round(seconds / 86400)} روز`;
}
exports.default = {
    generateToken,
    generateUUID,
    sleep,
    retryAsync,
    deepClone,
    isPositiveInteger,
    safeParseJSON,
    formatDuration,
};
//# sourceMappingURL=index.js.map