/**
 * RezeBot — Shared Utilities
 * Common helper functions used across modules.
 */

/**
 * Generate a random token of specified length using crypto-safe random bytes.
 */
export function generateToken(length: number = 32): string {
  const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  const array = new Uint8Array(length);
  crypto.getRandomValues(array);
  return Array.from(array, (i) => chars[i % chars.length]).join('');
}

/**
 * Generate a UUID v4.
 */
export function generateUUID(): string {
  return crypto.randomUUID();
}

/**
 * Sleep for the specified number of milliseconds.
 */
export function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * Retry an async function with exponential backoff.
 */
export async function retryAsync<T>(
  fn: () => Promise<T>,
  maxRetries: number = 3,
  delayMs: number = 500,
  backoffFactor: number = 2
): Promise<T> {
  let lastError: Error | undefined;
  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      return await fn();
    } catch (error) {
      lastError = error instanceof Error ? error : new Error(String(error));
      if (attempt === maxRetries) break;
      const delay = delayMs * Math.pow(backoffFactor, attempt);
      await sleep(delay);
    }
  }
  throw lastError;
}

/**
 * Deep clone an object.
 */
export function deepClone<T>(obj: T): T {
  if (obj === null || typeof obj !== 'object') return obj;
  if (obj instanceof Date) return new Date(obj.getTime()) as T;
  if (obj instanceof Array) return obj.map((item) => deepClone(item)) as T;
  if (typeof (obj as Record<string, unknown>) === 'object') {
    const cloned: Record<string, unknown> = {};
    for (const key in obj as Record<string, unknown>) {
      cloned[key] = deepClone((obj as Record<string, unknown>)[key]);
    }
    return cloned as T;
  }
  return obj;
}

/**
 * Check if a value is a valid positive integer.
 */
export function isPositiveInteger(value: unknown): value is number {
  return typeof value === 'number' && Number.isInteger(value) && value > 0;
}

/**
 * Safe JSON parse.
 */
export function safeParseJSON<T = unknown>(str: string): T | null {
  try {
    return JSON.parse(str) as T;
  } catch {
    return null;
  }
}

/**
 * Format a duration in seconds to a human-readable string (Persian-aware).
 */
export function formatDuration(seconds: number): string {
  if (seconds < 60) return `${seconds} ثانیه`;
  if (seconds < 3600) return `${Math.floor(seconds / 60)} دقیقه`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)} ساعت`;
  return `${Math.round(seconds / 86400)} روز`;
}

export default {
  generateToken,
  generateUUID,
  sleep,
  retryAsync,
  deepClone,
  isPositiveInteger,
  safeParseJSON,
  formatDuration,
};
