"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Router = void 0;
exports.getRouter = getRouter;
const grammy_1 = require("grammy");
const commands_1 = require("../commands");
const moderation_1 = require("../commands/moderation");
const logging_1 = require("../../core/logging");
const feature_flags_1 = require("../../core/feature-flags");
const errorHandler_1 = require("../middleware/errorHandler");
const log = logging_1.LoggerProvider.get('Router');
class Router {
    static instance;
    composer;
    constructor() {
        this.composer = new grammy_1.Composer();
        this.setup();
    }
    static getInstance() {
        if (!Router.instance) {
            Router.instance = new Router();
        }
        return Router.instance.composer;
    }
    setup() {
        this.composer.use(errorHandler_1.errorHandler);
        // Core commands
        this.composer.command('start', commands_1.handleStart);
        this.composer.command('help', commands_1.handleHelp);
        this.composer.command('ping', async (ctx) => {
            await ctx.reply('🏓 پونگ! ربات فعال است.');
        });
        // Moderation commands
        this.composer.command('ban', moderation_1.handleBan);
        this.composer.command('kick', moderation_1.handleKick);
        this.composer.command('mute', moderation_1.handleMute);
        this.composer.command('warn', moderation_1.handleWarn);
        this.composer.command('delete', moderation_1.handleDelete);
        this.composer.command('purge', moderation_1.handleDelete);
        this.composer.command('lock', moderation_1.handleLock);
        this.composer.command('unlock', moderation_1.handleUnlock);
        this.composer.command('quarantine', moderation_1.handleQuarantine);
        this.composer.command('unquarantine', moderation_1.handleUnquarantine);
        this.composer.command('role', async (ctx) => {
            await ctx.reply('⚙️ دستور role در حال توسعه است.');
        });
        // Security commands
        this.composer.command('report', async (ctx) => {
            await ctx.reply('🛡️ لطفاً شکایت خود را ثبت کنید.');
        });
        this.composer.command('guardian', async (ctx) => {
            await ctx.reply('🛡️ Guardian Engine فعال است. وضعیت: OK');
        });
        // AI commands
        this.composer.command('translate', async (ctx) => {
            if (!feature_flags_1.featureFlags.isEnabled(feature_flags_1.FeatureFlag.AI_TRANSLATION)) {
                await ctx.reply('❌ این قابلیت غیرفعال است (سرویس AI مورد نیاز است).');
                return;
            }
            await ctx.reply('🌐 ترجمه در حال ساخت...');
        });
        this.composer.command('summarize', async (ctx) => {
            if (!feature_flags_1.featureFlags.isEnabled(feature_flags_1.FeatureFlag.AI_SUMMARIZATION)) {
                await ctx.reply('❌ این قابلیت غیرفعال است (سرویس AI مورد نیاز است).');
                return;
            }
            await ctx.reply('📝 خلاصه‌سازی در حال ساخت...');
        });
        this.composer.command('intent', async (ctx) => {
            await ctx.reply('🧠 پردازش نیت در حال ساخت...');
        });
        // Economy commands
        this.composer.command('balance', async (ctx) => {
            if (!feature_flags_1.featureFlags.isEnabled(feature_flags_1.FeatureFlag.ECONOMY_POINTS)) {
                await ctx.reply('❌ این قابلیت غیرفعال است.');
                return;
            }
            await ctx.reply('💰 در حال بررسی موجودی...');
        });
        this.composer.command('daily', async (ctx) => {
            if (!feature_flags_1.featureFlags.isEnabled(feature_flags_1.FeatureFlag.ECONOMY_DAILY)) {
                await ctx.reply('❌ این قابلیت غیرفعال است.');
                return;
            }
            await ctx.reply('🎁 دریافت جایزه روزانه در حال ساخت...');
        });
        this.composer.command('leaderboard', async (ctx) => {
            if (!feature_flags_1.featureFlags.isEnabled(feature_flags_1.FeatureFlag.ECONOMY_LEADERBOARD)) {
                await ctx.reply('❌ این قابلیت غیرفعال است.');
                return;
            }
            await ctx.reply('📊 رده‌بندی در حال ساخت...');
        });
        // Game commands
        this.composer.command('trivia', async (ctx) => {
            if (!feature_flags_1.featureFlags.isEnabled(feature_flags_1.FeatureFlag.GAMES_TRIVIA)) {
                await ctx.reply('❌ بازی فعال نیست.');
                return;
            }
            await ctx.reply('🎮 بازی سؤال و آینده در حال ساخت...');
        });
        this.composer.command('guess', async (ctx) => {
            if (!feature_flags_1.featureFlags.isEnabled(feature_flags_1.FeatureFlag.GAMES_GUESS)) {
                await ctx.reply('❌ بازی فعال نیست.');
                return;
            }
            await ctx.reply('🔢 بازی حدس عدد در حال ساخت...');
        });
        // FAQ and rules
        this.composer.command('faq', async (ctx) => {
            if (!feature_flags_1.featureFlags.isEnabled(feature_flags_1.FeatureFlag.FAQ_MANAGE)) {
                await ctx.reply('❌ این قابلیت غیرفعال است.');
                return;
            }
            await ctx.reply('❓ سؤالات مکرر در حال ساخت...');
        });
        this.composer.command('rules', async (ctx) => {
            await ctx.reply('📜 قوانین گروه در حال ساخت...');
        });
        // Welcome
        this.composer.command('welcome', async (ctx) => {
            if (!feature_flags_1.featureFlags.isEnabled(feature_flags_1.FeatureFlag.WELCOME_WELCOME)) {
                await ctx.reply('❌ این قابلیت غیرفعال است.');
                return;
            }
            await ctx.reply('👋 پیام خوش‌آمد در حال ساخت...');
        });
        // Tickets
        this.composer.command('tickets', async (ctx) => {
            if (!feature_flags_1.featureFlags.isEnabled(feature_flags_1.FeatureFlag.SUPPORT_TICKETS)) {
                await ctx.reply('❌ این قابلیت غیرفعال است.');
                return;
            }
            await ctx.reply('🎫 سیستم تیکت در حال ساخت...');
        });
        // Giveaway
        this.composer.command('giveaway', async (ctx) => {
            if (!feature_flags_1.featureFlags.isEnabled(feature_flags_1.FeatureFlag.GIVEAWAY_CREATE)) {
                await ctx.reply('❌ این قابلیت غیرفعال است.');
                return;
            }
            await ctx.reply('🎉 سیستم گیروی در حال ساخت...');
        });
        // Settings
        this.composer.command('settings', async (ctx) => {
            await ctx.reply('⚙️ تنظیمات در حال ساخت...');
        });
        // Analytics
        this.composer.command('analytics', async (ctx) => {
            if (!feature_flags_1.featureFlags.isEnabled(feature_flags_1.FeatureFlag.ANALYTICS_DASHBOARD)) {
                await ctx.reply('❌ این قابلیت غیرفعال است.');
                return;
            }
            await ctx.reply('📊 آمار در حال بارگیری...');
        });
        // Callback query handlers
        this.composer.on('callback_query:data', async (ctx) => {
            const data = ctx.callbackQuery.data;
            if (!data)
                return;
            log.debug('Callback query received', { data });
            if (data === 'help') {
                await (0, commands_1.handleHelp)(ctx);
                await ctx.answerCallbackQuery();
            }
            else if (data.startsWith('settings:')) {
                await ctx.answerCallbackQuery();
                await ctx.editMessageText('⚙️ تنظیمات در حال ساخت...');
            }
            else if (data === 'security:main') {
                await ctx.answerCallbackQuery();
                await ctx.editMessageText('🛡️ منوی امنیت در حال ساخت...');
            }
            else if (data === 'ai:main') {
                await ctx.answerCallbackQuery();
                const aiEnabled = feature_flags_1.featureFlags.isEnabled(feature_flags_1.FeatureFlag.AI_INTENT_PARSING);
                await ctx.editMessageText(`🤖 هوش مصنوعی: ${aiEnabled ? 'فعال ✅' : 'غیرفعال ❌ (سرویس مورد نیاز)'}`);
            }
            else if (data === 'analytics:main') {
                await ctx.answerCallbackQuery();
                await ctx.editMessageText('📊 داشبورد آمار در حال ساخت...');
            }
            else if (data === 'games:main') {
                await ctx.answerCallbackQuery();
                await ctx.editMessageText('🎮 بازی‌ها در حال ساخت...');
            }
        });
        log.info('Router setup complete');
    }
}
exports.Router = Router;
function getRouter() {
    return Router.getInstance();
}
//# sourceMappingURL=router.js.map