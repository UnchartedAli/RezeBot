import { Composer } from 'grammy';
import { BotContext } from '../types';
import { handleStart, handleHelp } from '../commands';
import {
  handleBan,
  handleKick,
  handleMute,
  handleWarn,
  handleDelete,
  handleLock,
  handleUnlock,
  handleQuarantine,
  handleUnquarantine,
} from '../commands/moderation';
import { LoggerProvider } from '../../core/logging';
import { featureFlags, FeatureFlag } from '../../core/feature-flags';
import { errorHandler } from '../middleware/errorHandler';

const log = LoggerProvider.get('Router');

export class Router {
  private static instance: Router;
  private composer: Composer<BotContext>;

  private constructor() {
    this.composer = new Composer<BotContext>();
    this.setup();
  }

  static getInstance(): Composer<BotContext> {
    if (!Router.instance) {
      Router.instance = new Router();
    }
    return Router.instance.composer;
  }

  private setup(): void {
    this.composer.use(errorHandler);

    // Core commands
    this.composer.command('start', handleStart);
    this.composer.command('help', handleHelp);
    this.composer.command('ping', async (ctx) => {
      await ctx.reply('🏓 پونگ! ربات فعال است.');
    });

    // Moderation commands
    this.composer.command('ban', handleBan);
    this.composer.command('kick', handleKick);
    this.composer.command('mute', handleMute);
    this.composer.command('warn', handleWarn);
    this.composer.command('delete', handleDelete);
    this.composer.command('purge', handleDelete);
    this.composer.command('lock', handleLock);
    this.composer.command('unlock', handleUnlock);
    this.composer.command('quarantine', handleQuarantine);
    this.composer.command('unquarantine', handleUnquarantine);
    this.composer.command('role', async (ctx) => {
      await ctx.reply('⚙️ دستور role در حال توسعه است.');
    });

    // Security commands
    this.composer.command('report', async (ctx) => {
      await ctx.reply('🛡️ لطفاً شکایت خود را ثبت کنید.');
    });
    this.composer.command('guardian', async (ctx) => {
      await ctx.reply('🛡️ Guardian Engine فعال است. وضعیت: OK');
    });

    // AI commands
    this.composer.command('translate', async (ctx) => {
      if (!featureFlags.isEnabled(FeatureFlag.AI_TRANSLATION)) {
        await ctx.reply('❌ این قابلیت غیرفعال است (سرویس AI مورد نیاز است).');
        return;
      }
      await ctx.reply('🌐 ترجمه در حال ساخت...');
    });
    this.composer.command('summarize', async (ctx) => {
      if (!featureFlags.isEnabled(FeatureFlag.AI_SUMMARIZATION)) {
        await ctx.reply('❌ این قابلیت غیرفعال است (سرویس AI مورد نیاز است).');
        return;
      }
      await ctx.reply('📝 خلاصه‌سازی در حال ساخت...');
    });
    this.composer.command('intent', async (ctx) => {
      await ctx.reply('🧠 پردازش نیت در حال ساخت...');
    });

    // Economy commands
    this.composer.command('balance', async (ctx) => {
      if (!featureFlags.isEnabled(FeatureFlag.ECONOMY_POINTS)) {
        await ctx.reply('❌ این قابلیت غیرفعال است.');
        return;
      }
      await ctx.reply('💰 در حال بررسی موجودی...');
    });
    this.composer.command('daily', async (ctx) => {
      if (!featureFlags.isEnabled(FeatureFlag.ECONOMY_DAILY)) {
        await ctx.reply('❌ این قابلیت غیرفعال است.');
        return;
      }
      await ctx.reply('🎁 دریافت جایزه روزانه در حال ساخت...');
    });
    this.composer.command('leaderboard', async (ctx) => {
      if (!featureFlags.isEnabled(FeatureFlag.ECONOMY_LEADERBOARD)) {
        await ctx.reply('❌ این قابلیت غیرفعال است.');
        return;
      }
      await ctx.reply('📊 رده‌بندی در حال ساخت...');
    });

    // Game commands
    this.composer.command('trivia', async (ctx) => {
      if (!featureFlags.isEnabled(FeatureFlag.GAMES_TRIVIA)) {
        await ctx.reply('❌ بازی فعال نیست.');
        return;
      }
      await ctx.reply('🎮 بازی سؤال و آینده در حال ساخت...');
    });
    this.composer.command('guess', async (ctx) => {
      if (!featureFlags.isEnabled(FeatureFlag.GAMES_GUESS)) {
        await ctx.reply('❌ بازی فعال نیست.');
        return;
      }
      await ctx.reply('🔢 بازی حدس عدد در حال ساخت...');
    });

    // FAQ and rules
    this.composer.command('faq', async (ctx) => {
      if (!featureFlags.isEnabled(FeatureFlag.FAQ_MANAGE)) {
        await ctx.reply('❌ این قابلیت غیرفعال است.');
        return;
      }
      await ctx.reply('❓ سؤالات مکرر در حال ساخت...');
    });
    this.composer.command('rules', async (ctx) => {
      await ctx.reply('📜 قوانین گروه در حال ساخت...');
    });

    // Welcome
    this.composer.command('welcome', async (ctx) => {
      if (!featureFlags.isEnabled(FeatureFlag.WELCOME_WELCOME)) {
        await ctx.reply('❌ این قابلیت غیرفعال است.');
        return;
      }
      await ctx.reply('👋 پیام خوش‌آمد در حال ساخت...');
    });

    // Tickets
    this.composer.command('tickets', async (ctx) => {
      if (!featureFlags.isEnabled(FeatureFlag.SUPPORT_TICKETS)) {
        await ctx.reply('❌ این قابلیت غیرفعال است.');
        return;
      }
      await ctx.reply('🎫 سیستم تیکت در حال ساخت...');
    });

    // Giveaway
    this.composer.command('giveaway', async (ctx) => {
      if (!featureFlags.isEnabled(FeatureFlag.GIVEAWAY_CREATE)) {
        await ctx.reply('❌ این قابلیت غیرفعال است.');
        return;
      }
      await ctx.reply('🎉 سیستم گیروی در حال ساخت...');
    });

    // Settings
    this.composer.command('settings', async (ctx) => {
      await ctx.reply('⚙️ تنظیمات در حال ساخت...');
    });

    // Analytics
    this.composer.command('analytics', async (ctx) => {
      if (!featureFlags.isEnabled(FeatureFlag.ANALYTICS_DASHBOARD)) {
        await ctx.reply('❌ این قابلیت غیرفعال است.');
        return;
      }
      await ctx.reply('📊 آمار در حال بارگیری...');
    });

    // Callback query handlers
    this.composer.on('callback_query:data', async (ctx) => {
      const data = ctx.callbackQuery.data;
      if (!data) return;

      log.debug('Callback query received', { data });

      if (data === 'help') {
        await handleHelp(ctx);
        await ctx.answerCallbackQuery();
      } else if (data.startsWith('settings:')) {
        await ctx.answerCallbackQuery();
        await ctx.editMessageText('⚙️ تنظیمات در حال ساخت...');
      } else if (data === 'security:main') {
        await ctx.answerCallbackQuery();
        await ctx.editMessageText('🛡️ منوی امنیت در حال ساخت...');
      } else if (data === 'ai:main') {
        await ctx.answerCallbackQuery();
        const aiEnabled = featureFlags.isEnabled(FeatureFlag.AI_INTENT_PARSING);
        await ctx.editMessageText(
          `🤖 هوش مصنوعی: ${aiEnabled ? 'فعال ✅' : 'غیرفعال ❌ (سرویس مورد نیاز)'}`
        );
      } else if (data === 'analytics:main') {
        await ctx.answerCallbackQuery();
        await ctx.editMessageText('📊 داشبورد آمار در حال ساخت...');
      } else if (data === 'games:main') {
        await ctx.answerCallbackQuery();
        await ctx.editMessageText('🎮 بازی‌ها در حال ساخت...');
      }
    });

    log.info('Router setup complete');
  }
}

export function getRouter(): Composer<BotContext> {
  return Router.getInstance();
}
