import { BotContext } from '../types';
export interface TargetResolution {
    type: 'reply' | 'username' | 'id' | 'mention' | 'name';
    value: string;
    resolvedId?: number;
    resolvedName?: string;
    confidence: number;
}
declare class TargetResolver {
    resolve(ctx: BotContext): Promise<TargetResolution | null>;
    private resolveUsername;
    private resolveByName;
}
export declare const targetResolver: TargetResolver;
export {};
//# sourceMappingURL=targetResolver.d.ts.map