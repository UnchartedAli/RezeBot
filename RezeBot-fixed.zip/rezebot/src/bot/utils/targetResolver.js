"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.targetResolver = void 0;
const logging_1 = require("../../core/logging");
const log = logging_1.LoggerProvider.get('TargetResolver');
class TargetResolver {
    async resolve(ctx) {
        const message = ctx.message;
        if (!message)
            return null;
        // 1. Reply
        if (message.reply_to_message?.from) {
            const user = message.reply_to_message.from;
            const name = user.first_name || user.username || 'Unknown';
            return {
                type: 'reply',
                value: name,
                resolvedId: user.id,
                resolvedName: name,
                confidence: 1.0,
            };
        }
        const text = message.text || '';
        const args = text.split(' ').slice(1).filter((a) => a);
        if (args.length === 0)
            return null;
        // 2. @username
        for (const arg of args) {
            if (arg.startsWith('@')) {
                const username = arg.slice(1);
                const user = await this.resolveUsername(ctx, username);
                if (user) {
                    return {
                        type: 'username',
                        value: username,
                        resolvedId: user.id,
                        resolvedName: user.first_name || user.username || 'Unknown',
                        confidence: 0.95,
                    };
                }
            }
        }
        // 3. User ID
        for (const arg of args) {
            if (/^\d+$/.test(arg)) {
                return {
                    type: 'id',
                    value: arg,
                    resolvedId: parseInt(arg),
                    confidence: 0.9,
                };
            }
        }
        // 4. Mention
        const mentionMatch = text.match(/\[([^\]]+)\]\(tg:\/\/user\?id=(\d+)\)/);
        if (mentionMatch) {
            return {
                type: 'mention',
                value: mentionMatch[1],
                resolvedId: parseInt(mentionMatch[2]),
                confidence: 1.0,
            };
        }
        // 5. Name (only with high confidence)
        if (args.length > 0) {
            const nameQuery = args.join(' ');
            const user = await this.resolveByName(ctx, nameQuery);
            if (user) {
                return {
                    type: 'name',
                    value: nameQuery,
                    resolvedId: user.id,
                    resolvedName: user.first_name || user.username || 'Unknown',
                    confidence: 0.85,
                };
            }
        }
        return null;
    }
    async resolveUsername(ctx, username) {
        return null;
    }
    async resolveByName(ctx, name) {
        return null;
    }
}
exports.targetResolver = new TargetResolver();
//# sourceMappingURL=targetResolver.js.map