"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.sessionStorage = exports.PostgreSQLSessionStorage = void 0;
const pool_1 = require("../db/pool");
const logging_1 = require("../core/logging");
const logger = logging_1.LoggerProvider.get('PostgreSQLStorageAdapter');
class PostgreSQLSessionStorage {
    async read(key) {
        try {
            const result = await (0, pool_1.query)('SELECT data FROM bot_sessions WHERE key = $1 AND (expires_at IS NULL OR expires_at > NOW())', [key]);
            if (result.rows.length === 0)
                return undefined;
            return result.rows[0].data;
        }
        catch (error) {
            logger.error('Failed to read session', { key, error: String(error) });
            return undefined;
        }
    }
    async write(key, value) {
        try {
            const expiresAt = new Date();
            expiresAt.setHours(expiresAt.getHours() + 24);
            await (0, pool_1.query)(`INSERT INTO bot_sessions (key, data, expires_at)
         VALUES ($1, $2, $3)
         ON CONFLICT (key) DO UPDATE SET
           data = $2,
           expires_at = $3`, [key, JSON.stringify(value), expiresAt]);
        }
        catch (error) {
            logger.error('Failed to write session', { key, error: String(error) });
        }
    }
    async delete(key) {
        try {
            await (0, pool_1.query)('DELETE FROM bot_sessions WHERE key = $1', [key]);
        }
        catch (error) {
            logger.error('Failed to delete session', { key, error: String(error) });
        }
    }
    async has(key) {
        try {
            const result = await (0, pool_1.query)('SELECT 1 FROM bot_sessions WHERE key = $1 AND (expires_at IS NULL OR expires_at > NOW())', [key]);
            return result.rows.length > 0;
        }
        catch (error) {
            logger.error('Failed to check session existence', { key, error: String(error) });
            return false;
        }
    }
    async *readAllKeys() {
        try {
            const result = await (0, pool_1.query)('SELECT key FROM bot_sessions WHERE expires_at IS NULL OR expires_at > NOW()');
            for (const row of result.rows) {
                yield row.key;
            }
        }
        catch (error) {
            logger.error('Failed to read all session keys', { error: String(error) });
        }
    }
}
exports.PostgreSQLSessionStorage = PostgreSQLSessionStorage;
exports.sessionStorage = new PostgreSQLSessionStorage();
//# sourceMappingURL=sessionStorage.js.map