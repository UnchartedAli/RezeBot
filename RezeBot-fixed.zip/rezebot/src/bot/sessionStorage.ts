import { StorageAdapter } from 'grammy';
import { SessionData } from './types';
import { query } from '../db/pool';
import { LoggerProvider } from '../core/logging';

const logger = LoggerProvider.get('PostgreSQLStorageAdapter');

export class PostgreSQLSessionStorage implements StorageAdapter<SessionData> {
  async read(key: string): Promise<SessionData | undefined> {
    try {
      const result = await query<{ data: SessionData }>(
        'SELECT data FROM bot_sessions WHERE key = $1 AND (expires_at IS NULL OR expires_at > NOW())',
        [key]
      );

      if (result.rows.length === 0) return undefined;
      return result.rows[0].data;
    } catch (error) {
      logger.error('Failed to read session', { key, error: String(error) });
      return undefined;
    }
  }

  async write(key: string, value: SessionData): Promise<void> {
    try {
      const expiresAt = new Date();
      expiresAt.setHours(expiresAt.getHours() + 24);

      await query(
        `INSERT INTO bot_sessions (key, data, expires_at)
         VALUES ($1, $2, $3)
         ON CONFLICT (key) DO UPDATE SET
           data = $2,
           expires_at = $3`,
        [key, JSON.stringify(value), expiresAt]
      );
    } catch (error) {
      logger.error('Failed to write session', { key, error: String(error) });
    }
  }

  async delete(key: string): Promise<void> {
    try {
      await query('DELETE FROM bot_sessions WHERE key = $1', [key]);
    } catch (error) {
      logger.error('Failed to delete session', { key, error: String(error) });
    }
  }

  async has(key: string): Promise<boolean> {
    try {
      const result = await query(
        'SELECT 1 FROM bot_sessions WHERE key = $1 AND (expires_at IS NULL OR expires_at > NOW())',
        [key]
      );
      return result.rows.length > 0;
    } catch (error) {
      logger.error('Failed to check session existence', { key, error: String(error) });
      return false;
    }
  }

  async *readAllKeys(): AsyncIterable<string> {
    try {
      const result = await query<{ key: string }>(
        'SELECT key FROM bot_sessions WHERE expires_at IS NULL OR expires_at > NOW()'
      );
      for (const row of result.rows) {
        yield row.key;
      }
    } catch (error) {
      logger.error('Failed to read all session keys', { error: String(error) });
    }
  }
}

export const sessionStorage = new PostgreSQLSessionStorage();
