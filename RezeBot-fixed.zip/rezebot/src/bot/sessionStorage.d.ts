import { StorageAdapter } from 'grammy';
import { SessionData } from './types';
export declare class PostgreSQLSessionStorage implements StorageAdapter<SessionData> {
    read(key: string): Promise<SessionData | undefined>;
    write(key: string, value: SessionData): Promise<void>;
    delete(key: string): Promise<void>;
    has(key: string): Promise<boolean>;
    readAllKeys(): AsyncIterable<string>;
}
export declare const sessionStorage: PostgreSQLSessionStorage;
//# sourceMappingURL=sessionStorage.d.ts.map