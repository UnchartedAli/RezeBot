import { Context } from 'grammy';
import { SessionFlavor } from 'grammy';
import type { ActionSource } from '../core/types';

export interface SessionData {
  userId: number;
  chatId: number | null;
  state: Record<string, any>;
  pendingAction: {
    type: string;
    target: any;
    params: Record<string, unknown>;
  } | null;
  lastCommand: string | null;
  lastCommandTime: number | null;
  data: Record<string, any>;
}

export interface BotContext extends Context, SessionFlavor<SessionData> {}

declare module 'grammy' {
  interface Context {
    state: {
      user?: unknown;
      chat?: unknown;
      source?: ActionSource;
      [key: string]: unknown;
    };
  }
}

export type { Context as GrammYContext } from 'grammy';
export type { SessionFlavor } from 'grammy';
