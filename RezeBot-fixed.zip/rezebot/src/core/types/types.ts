/**
 * RezeBot — Core Types
 * Central type definitions for the platform.
 */

export type Role =
  | 'owner'
  | 'creator'
  | 'administrator'
  | 'moderator'
  | 'trusted'
  | 'member'
  | 'user'
  | 'restricted';

export type ActionSource =
  | 'command'
  | 'natural_language'
  | 'inline_button'
  | 'web_panel'
  | 'mini_app'
  | 'automation'
  | 'ai'
  | 'scheduler';

export type ActionStatus = 'success' | 'failed' | 'blocked' | 'error';

export type ModerationActionType =
  | 'ban'
  | 'kick'
  | 'mute'
  | 'warn'
  | 'delete'
  | 'lock'
  | 'unlock'
  | 'quarantine'
  | 'unquarantine';

export type UserStatus = 'active' | 'banned' | 'muted' | 'quarantined' | 'restricted';

export type ChatType = 'private' | 'group' | 'supergroup' | 'channel';

export interface UserRecord {
  id: number;
  username: string | null;
  first_name: string | null;
  last_name: string | null;
  is_bot: boolean;
  language_code: string | null;
  is_premium?: boolean;
  join_date: Date;
  last_seen: Date;
  status: UserStatus;
  risk_score: number;
  warning_count: number;
  warn_expiry: Date | null;
  mute_expiry: Date | null;
  ban_expiry: Date | null;
  quarantine_expiry: Date | null;
  total_warnings: number;
  total_restricts: number;
  total_actions: number;
  created_at: Date;
  updated_at: Date;
}

export interface ChatSettings {
  language: string;
  welcomeEnabled: boolean;
  rulesEnabled: boolean;
  autoDelete: boolean;
  deleteAfter: number;
  antiSpam: boolean;
  antiRaid: boolean;
  guardian: boolean;
  aiEnabled: boolean;
  logsEnabled: boolean;
  logsChannelId: number | null;
}

export interface ChatConfig {
  id: number;
  chatId: number;
  title: string | null;
  type: ChatType;
  username: string | null;
  inviteLink: string | null;
  description: string | null;
  settings: ChatSettings | Record<string, unknown> | null;
  features: Record<string, boolean> | null;
  created_at?: Date;
  updated_at?: Date;
}

export interface PermissionCheck {
  allowed: boolean;
  role: Role;
  reason: string;
  requiredRole?: Role;
}

export interface BotPermissions {
  canRestrict: boolean;
  canDelete: boolean;
  canPin: boolean;
  canInvite: boolean;
  canChangeInfo: boolean;
  canManageTopics: boolean;
  canPostMessages: boolean;
  isAdministrator: boolean;
  isCreator: boolean;
}

export interface AuditLogEntry {
  chatId: number;
  actorId: number;
  targetId?: number;
  action: string;
  reason?: string;
  source: ActionSource;
  result: ActionStatus;
  details?: Record<string, unknown>;
  metadata?: Record<string, unknown>;
}

export interface ParsedIntent {
  intent: string;
  action: string;
  target?: {
    type: 'reply' | 'username' | 'user_id' | 'mention' | 'name';
    value: string;
    userId?: number;
  };
  durationSeconds?: number;
  reason?: string;
  confidence: number;
  rawText: string;
  normalizedText: string;
  isPersian: boolean;
}

export interface ResolvedTarget {
  userId: number;
  username?: string;
  displayName: string;
  confidence: number;
  source: 'reply' | 'username' | 'user_id' | 'mention' | 'name';
  isBot?: boolean;
}

export interface GuardianRiskScore {
  score: number;
  factors: {
    accountAge: number;
    joinBurst: number;
    messageVelocity: number;
    duplicateRatio: number;
    linkFrequency: number;
    warnings: number;
    behavior: number;
  };
  recommendation: 'normal' | 'monitor' | 'restrict' | 'quarantine';
}

export interface ModerationResult {
  success: boolean;
  action: string;
  targetId?: number;
  status: ActionStatus;
  message: string;
  details?: Record<string, unknown>;
}

export type FeatureCategory =
  | 'core'
  | 'community'
  | 'intelligence'
  | 'entertainment'
  | 'market'
  | 'advanced';

export interface FeatureFlagInfo {
  key: string;
  displayName: string;
  enabled: boolean;
  status: string;
  category: FeatureCategory;
  priority: 'P0' | 'P1' | 'P2' | 'P3' | 'P4' | 'P5' | '';
}

export interface ModerationContext {
  actorId: number;
  chatId: number;
  targetId: number;
  action: ModerationActionType;
  reason?: string;
  durationSeconds?: number | null;
  source: ActionSource;
}

export interface ActionExecutionResult {
  success: boolean;
  action: ModerationActionType;
  targetId: number;
  chatId: number;
  status: ActionStatus;
  message: string;
  metadata?: Record<string, unknown>;
}

export type AuditAction = string;

export type ActionTargetType = 'reply' | 'username' | 'user_id' | 'id' | 'mention' | 'name';

export interface ActionTarget {
  type: ActionTargetType;
  value: string;
  resolvedId?: number;
  confidence?: number;
}

export interface ActionContext {
  chatId: number;
  userId: number;
  messageId?: number;
  replyToId?: number;
  source: ActionSource;
}

export interface ActionIntent {
  type: string;
  command: string;
  target: ActionTarget;
  params: Record<string, unknown>;
  context: ActionContext;
  requiresConfirmation?: boolean;
}

export interface ActionResult {
  success: boolean;
  action: AuditAction;
  actorId: number;
  chatId: number;
  targetId?: number;
  reason?: string;
  duration?: number;
  source: ActionSource | string;
  result: ActionStatus;
  details?: Record<string, unknown>;
  timestamp: Date;
}

export interface PersianIntent {
  intent: string;
  entities: Record<string, unknown>;
  confidence: number;
  originalText: string;
  normalizedText: string;
  detectedLanguage: 'fa' | 'mixed' | 'other';
}

export interface NlpResult {
  intent: PersianIntent;
  action?: ActionIntent;
  actionType?: string;
  entities: Record<string, unknown>;
  confidence: number;
}
