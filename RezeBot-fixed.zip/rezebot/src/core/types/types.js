"use strict";
/**
 * RezeBot — Core Types
 * Central type definitions for the platform.
 */
Object.defineProperty(exports, "__esModule", { value: true });
//# sourceMappingURL=types.js.map