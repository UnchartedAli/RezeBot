"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.LoggerProvider = exports.createLogger = exports.log = void 0;
const pino_1 = __importDefault(require("pino"));
const os_1 = __importDefault(require("os"));
const logger = (0, pino_1.default)({
    level: process.env.LOG_LEVEL || (process.env.NODE_ENV === 'production' ? 'info' : 'debug'),
    base: {
        pid: process.pid,
        hostname: os_1.default.hostname(),
    },
    timestamp: pino_1.default.stdTimeFunctions.isoTime,
    redact: {
        paths: ['req.headers.authorization', 'req.headers.cookie', 'password', 'token', 'BOT_TOKEN', 'AI_API_KEY'],
        censor: '[REDACTED]',
    },
});
const wrapLogger = (pinoLogger) => {
    const emit = (level, msg, ctx) => {
        if (ctx)
            pinoLogger[level](ctx, msg);
        else
            pinoLogger[level](msg);
    };
    return {
        fatal: (msg, ctx) => emit('fatal', msg, ctx),
        error: (msg, ctx) => emit('error', msg, ctx),
        warn: (msg, ctx) => emit('warn', msg, ctx),
        info: (msg, ctx) => emit('info', msg, ctx),
        debug: (msg, ctx) => emit('debug', msg, ctx),
        trace: (msg, ctx) => emit('trace', msg, ctx),
        child: (ctx) => wrapLogger(pinoLogger.child(ctx)),
    };
};
exports.log = wrapLogger(logger);
const createLogger = (module) => {
    return exports.log.child({ module });
};
exports.createLogger = createLogger;
class LoggerProvider {
    static loggers = new Map();
    static get(module) {
        if (!LoggerProvider.loggers.has(module)) {
            LoggerProvider.loggers.set(module, (0, exports.createLogger)(module));
        }
        return LoggerProvider.loggers.get(module);
    }
}
exports.LoggerProvider = LoggerProvider;
exports.default = exports.log;
//# sourceMappingURL=logger.js.map