"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LoggerProvider = exports.createLogger = exports.log = void 0;
var logger_1 = require("./logger");
Object.defineProperty(exports, "log", { enumerable: true, get: function () { return logger_1.log; } });
Object.defineProperty(exports, "createLogger", { enumerable: true, get: function () { return logger_1.createLogger; } });
Object.defineProperty(exports, "LoggerProvider", { enumerable: true, get: function () { return logger_1.LoggerProvider; } });
//# sourceMappingURL=index.js.map