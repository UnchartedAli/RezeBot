export interface LogContext {
    userId?: number | string;
    chatId?: number | string;
    action?: string;
    requestId?: string;
    [key: string]: unknown;
}
export type LogLevel = 'fatal' | 'error' | 'warn' | 'info' | 'debug' | 'trace';
export interface Logger {
    fatal: (msg: string, ctx?: LogContext) => void;
    error: (msg: string, ctx?: LogContext) => void;
    warn: (msg: string, ctx?: LogContext) => void;
    info: (msg: string, ctx?: LogContext) => void;
    debug: (msg: string, ctx?: LogContext) => void;
    trace: (msg: string, ctx?: LogContext) => void;
    child: (ctx: LogContext) => Logger;
}
export declare const log: Logger;
export declare const createLogger: (module: string) => Logger;
export declare class LoggerProvider {
    private static loggers;
    static get(module: string): Logger;
}
export default log;
//# sourceMappingURL=logger.d.ts.map