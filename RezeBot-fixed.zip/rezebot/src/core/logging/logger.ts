import pino from 'pino';
import os from 'os';

export interface LogContext {
  userId?: number | string;
  chatId?: number | string;
  action?: string;
  requestId?: string;
  [key: string]: unknown;
}

export type LogLevel = 'fatal' | 'error' | 'warn' | 'info' | 'debug' | 'trace';

const logger = pino({
  level: process.env.LOG_LEVEL || (process.env.NODE_ENV === 'production' ? 'info' : 'debug'),
  base: {
    pid: process.pid,
    hostname: os.hostname(),
  },
  timestamp: pino.stdTimeFunctions.isoTime,
  redact: {
    paths: ['req.headers.authorization', 'req.headers.cookie', 'password', 'token', 'BOT_TOKEN', 'AI_API_KEY'],
    censor: '[REDACTED]',
  },
});

export interface Logger {
  fatal: (msg: string, ctx?: LogContext) => void;
  error: (msg: string, ctx?: LogContext) => void;
  warn: (msg: string, ctx?: LogContext) => void;
  info: (msg: string, ctx?: LogContext) => void;
  debug: (msg: string, ctx?: LogContext) => void;
  trace: (msg: string, ctx?: LogContext) => void;
  child: (ctx: LogContext) => Logger;
}

const wrapLogger = (pinoLogger: pino.Logger): Logger => {
  const emit = (level: LogLevel, msg: string, ctx?: LogContext) => {
    if (ctx) pinoLogger[level](ctx, msg);
    else pinoLogger[level](msg);
  };

  return {
    fatal: (msg, ctx) => emit('fatal', msg, ctx),
    error: (msg, ctx) => emit('error', msg, ctx),
    warn: (msg, ctx) => emit('warn', msg, ctx),
    info: (msg, ctx) => emit('info', msg, ctx),
    debug: (msg, ctx) => emit('debug', msg, ctx),
    trace: (msg, ctx) => emit('trace', msg, ctx),
    child: (ctx: LogContext) => wrapLogger(pinoLogger.child(ctx)),
  };
};

export const log = wrapLogger(logger);

export const createLogger = (module: string): Logger => {
  return log.child({ module });
};

export class LoggerProvider {
  private static loggers = new Map<string, Logger>();

  static get(module: string): Logger {
    if (!LoggerProvider.loggers.has(module)) {
      LoggerProvider.loggers.set(module, createLogger(module));
    }
    return LoggerProvider.loggers.get(module)!;
  }
}

export default log;
