export { PermissionEngine, permissionEngine } from './PermissionEngine';
//# sourceMappingURL=index.d.ts.map