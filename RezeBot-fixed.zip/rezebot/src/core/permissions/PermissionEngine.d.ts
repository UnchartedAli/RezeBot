import { Role, PermissionCheck, BotPermissions } from '../types';
export declare class PermissionEngine {
    private static instance;
    private readonly api;
    private constructor();
    static getInstance(): PermissionEngine;
    normalizeRole(role: string): Role;
    getRoleLevel(role: Role | string): number;
    compareRoles(a: Role, b: Role): number;
    /**
     * Telegram membership is authoritative for creator/administrator/member status.
     * Local roles are used only for RezeBot-specific moderator/trusted roles.
     */
    getUserRole(userId: number, chatId: number): Promise<Role>;
    setUserRole(userId: number, chatId: number, role: Role, setBy: number): Promise<boolean>;
    private actionNeedsBotPermission;
    checkPermission(userId: number, chatId: number, requiredAction: string, requiredRole?: Role): Promise<PermissionCheck>;
    getBotPermissions(chatId: number): Promise<BotPermissions>;
    canPerformAction(userId: number, chatId: number, action: string): Promise<{
        allowed: boolean;
        role: Role;
        botPerms: BotPermissions;
    }>;
    getDefaultPermissions(_chatId: number): Promise<Record<Role, string[]>>;
}
export declare const permissionEngine: PermissionEngine;
export type { PermissionCheck, BotPermissions, Role };
//# sourceMappingURL=PermissionEngine.d.ts.map