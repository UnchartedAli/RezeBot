import { Api } from 'grammy';
import { Role, PermissionCheck, BotPermissions } from '../types';
import { getPool } from '../../db/pool';
import { LoggerProvider } from '../logging';
import { getConfig } from '../config';

const logger = LoggerProvider.get('PermissionEngine');

const ROLE_HIERARCHY: Record<Role, number> = {
  creator: 0,
  owner: 1,
  administrator: 2,
  moderator: 3,
  trusted: 4,
  member: 5,
  user: 5,
  restricted: 6,
};

const ROLE_ALIASES: Record<string, Role> = {
  admin: 'administrator',
  administrator: 'administrator',
  mod: 'moderator',
  owner: 'creator',
  creator: 'creator',
  super_admin: 'administrator',
  user: 'user',
  member: 'member',
  trusted: 'trusted',
};

function isGroupChatType(type: string | undefined): boolean {
  return type === 'group' || type === 'supergroup';
}

export class PermissionEngine {
  private static instance: PermissionEngine;
  private readonly api: Api;

  private constructor() {
    this.api = new Api(getConfig().BOT_TOKEN);
  }

  static getInstance(): PermissionEngine {
    if (!PermissionEngine.instance) PermissionEngine.instance = new PermissionEngine();
    return PermissionEngine.instance;
  }

  normalizeRole(role: string): Role {
    const normalized = role.toLowerCase();
    return ROLE_ALIASES[normalized] || (normalized as Role);
  }

  getRoleLevel(role: Role | string): number {
    const normalized = this.normalizeRole(role);
    return ROLE_HIERARCHY[normalized] ?? ROLE_HIERARCHY.member;
  }

  compareRoles(a: Role, b: Role): number {
    const levelA = this.getRoleLevel(a);
    const levelB = this.getRoleLevel(b);
    if (levelA < levelB) return 1;
    if (levelA > levelB) return -1;
    return 0;
  }

  /**
   * Telegram membership is authoritative for creator/administrator/member status.
   * Local roles are used only for RezeBot-specific moderator/trusted roles.
   */
  async getUserRole(userId: number, chatId: number): Promise<Role> {
    try {
      const chatResult = await getPool().query<{ type: string }>('SELECT type FROM chats WHERE id = $1', [chatId]);
      const chatType = chatResult.rows[0]?.type;
      if (chatType === 'private') return 'user';

      if (isGroupChatType(chatType)) {
        const member = await this.api.getChatMember(chatId, userId);
        if (member.status === 'creator') return 'creator';
        if (member.status === 'administrator') return 'administrator';
        if (member.status === 'restricted' && !member.is_member) return 'restricted';

        const local = await getPool().query<{ role: Role }>(
          'SELECT role FROM chat_members WHERE chat_id = $1 AND user_id = $2',
          [chatId, userId]
        );
        const localRole = local.rows[0]?.role;
        if (localRole === 'moderator' || localRole === 'trusted') return localRole;
        return member.status === 'restricted' ? 'restricted' : 'member';
      }

      const result = await getPool().query<{ role: Role }>(
        'SELECT role FROM chat_members WHERE chat_id = $1 AND user_id = $2',
        [chatId, userId]
      );
      return result.rows[0]?.role ?? 'member';
    } catch (error) {
      logger.warn('Failed to resolve Telegram user role', { userId, chatId, error: String(error) });
      return 'member';
    }
  }

  async setUserRole(userId: number, chatId: number, role: Role, setBy: number): Promise<boolean> {
    try {
      await getPool().query(
        `INSERT INTO chat_members (chat_id, user_id, role) VALUES ($1, $2, $3)
         ON CONFLICT (chat_id, user_id) DO UPDATE SET role = $3, updated_at = NOW()`,
        [chatId, userId, role]
      );
      logger.info('User role updated', { userId, chatId, role, setBy });
      return true;
    } catch (error) {
      logger.error('Failed to set user role', { userId, chatId, role, setBy, error: String(error) });
      return false;
    }
  }

  private actionNeedsBotPermission(action: string): keyof BotPermissions | null {
    const normalized = action.toLowerCase();
    if (['ban', 'kick', 'mute', 'quarantine', 'restrict', 'unrestrict'].includes(normalized)) return 'canRestrict';
    if (['delete', 'purge'].includes(normalized)) return 'canDelete';
    if (['pin', 'unpin'].includes(normalized)) return 'canPin';
    if (['invite'].includes(normalized)) return 'canInvite';
    if (['settings', 'change_info'].includes(normalized)) return 'canChangeInfo';
    if (['lock', 'unlock'].includes(normalized)) return 'canRestrict';
    return null;
  }

  async checkPermission(
    userId: number,
    chatId: number,
    requiredAction: string,
    requiredRole?: Role
  ): Promise<PermissionCheck> {
    const role = await this.getUserRole(userId, chatId);
    const roleLevel = this.getRoleLevel(role);

    if (role === 'member' || role === 'user' || role === 'restricted') {
      if (!requiredRole && requiredAction === 'report') {
        return { allowed: true, role, reason: 'Public action', requiredRole: role };
      }
    }

    let roleAllowed = false;
    if (requiredRole) {
      roleAllowed = roleLevel <= this.getRoleLevel(requiredRole);
    }

    try {
      const pool = getPool();
      const result = await pool.query<{ actions: string[] }>(
        'SELECT actions FROM permissions WHERE chat_id = $1 AND role = $2',
        [chatId, role]
      );
      const globalResult = await pool.query<{ actions: string[] }>(
        'SELECT actions FROM permissions WHERE chat_id IS NULL AND role = $1',
        [role]
      );
      const actions = [
        ...(result.rows[0]?.actions ?? []),
        ...(globalResult.rows[0]?.actions ?? []),
      ];
      const explicitlyAllowed = actions.includes(requiredAction) || actions.includes('*');

      const botPerms = await this.getBotPermissions(chatId);
      const requiredBotPerm = this.actionNeedsBotPermission(requiredAction);
      const botAllowed = !requiredBotPerm || Boolean(botPerms[requiredBotPerm]);

      if ((roleAllowed || explicitlyAllowed) && botAllowed) {
        return {
          allowed: true,
          role,
          reason: `Allowed for ${role}; Telegram bot permissions verified`,
          requiredRole: requiredRole || role,
        };
      }

      if ((roleAllowed || explicitlyAllowed) && !botAllowed) {
        return {
          allowed: false,
          role,
          reason: 'Bot lacks the Telegram administrator permission required for this action',
          requiredRole: requiredRole || role,
        };
      }

      return {
        allowed: false,
        role,
        reason: `User with role ${role} cannot perform action ${requiredAction}`,
        requiredRole: requiredRole || role,
      };
    } catch (error) {
      logger.error('Permission check failed', { userId, chatId, requiredAction, error: String(error) });
      return { allowed: false, role, reason: 'Permission check failed', requiredRole: requiredRole || role };
    }
  }

  async getBotPermissions(chatId: number): Promise<BotPermissions> {
    const denied: BotPermissions = {
      canRestrict: false,
      canDelete: false,
      canPin: false,
      canInvite: false,
      canChangeInfo: false,
      canManageTopics: false,
      canPostMessages: false,
      isAdministrator: false,
      isCreator: false,
    };

    try {
      const me = await this.api.getMe();
      const member = await this.api.getChatMember(chatId, me.id);

      if (member.status === 'creator') {
        return {
          canRestrict: true,
          canDelete: true,
          canPin: true,
          canInvite: true,
          canChangeInfo: true,
          canManageTopics: true,
          canPostMessages: true,
          isAdministrator: true,
          isCreator: true,
        };
      }

      if (member.status !== 'administrator') return denied;

      return {
        canRestrict: Boolean(member.can_restrict_members),
        canDelete: Boolean(member.can_delete_messages),
        canPin: Boolean(member.can_pin_messages),
        canInvite: Boolean(member.can_invite_users),
        canChangeInfo: Boolean(member.can_change_info),
        canManageTopics: Boolean(member.can_manage_topics),
        canPostMessages: true,
        isAdministrator: true,
        isCreator: false,
      };
    } catch (error) {
      logger.warn('Failed to query Telegram bot permissions', { chatId, error: String(error) });
      return denied;
    }
  }

  async canPerformAction(userId: number, chatId: number, action: string) {
    const role = await this.getUserRole(userId, chatId);
    const botPerms = await this.getBotPermissions(chatId);
    const check = await this.checkPermission(userId, chatId, action);
    return { allowed: check.allowed, role, botPerms };
  }

  async getDefaultPermissions(_chatId: number): Promise<Record<Role, string[]>> {
    return {
      creator: ['*'],
      administrator: ['*'],
      owner: ['*'],
      moderator: ['ban', 'kick', 'mute', 'warn', 'delete', 'lock', 'quarantine', 'filter_block', 'filter_unblock', 'faq_create', 'faq_update', 'faq_delete', 'welcome_update', 'rules_update', 'ticket_assign', 'economy_adjust', 'setting_change'],
      trusted: ['warn', 'delete', 'faq_create', 'ticket_create', 'economy_transfer'],
      member: ['ticket_create', 'report'],
      user: ['ticket_create', 'report'],
      restricted: [],
    };
  }
}

export const permissionEngine = PermissionEngine.getInstance();
export type { PermissionCheck, BotPermissions, Role };
