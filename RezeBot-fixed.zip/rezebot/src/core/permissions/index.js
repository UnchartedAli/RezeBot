"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.permissionEngine = exports.PermissionEngine = void 0;
var PermissionEngine_1 = require("./PermissionEngine");
Object.defineProperty(exports, "PermissionEngine", { enumerable: true, get: function () { return PermissionEngine_1.PermissionEngine; } });
Object.defineProperty(exports, "permissionEngine", { enumerable: true, get: function () { return PermissionEngine_1.permissionEngine; } });
//# sourceMappingURL=index.js.map