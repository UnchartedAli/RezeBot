import { LoggerProvider } from '../logging';

const logger = LoggerProvider.get('EventBus');

export type EventHandler<T = any> = (payload: T) => Promise<void> | void;

export interface EventSubscription {
  event: string;
  handler: EventHandler;
  priority: number;
  once: boolean;
  id: string;
}

export class EventBus {
  private static instance: EventBus;
  private handlers = new Map<string, EventSubscription[]>();
  private handlerCounter = 0;

  private constructor() {}

  static getInstance(): EventBus {
    if (!EventBus.instance) {
      EventBus.instance = new EventBus();
    }
    return EventBus.instance;
  }

  subscribe<T = any>(
    event: string,
    handler: EventHandler<T>,
    options?: { priority?: number; once?: boolean }
  ): string {
    const subscription: EventSubscription = {
      event,
      handler,
      priority: options?.priority ?? 0,
      once: options?.once ?? false,
      id: `handler_${++this.handlerCounter}`,
    };

    if (!this.handlers.has(event)) {
      this.handlers.set(event, []);
    }

    const eventHandlers = this.handlers.get(event)!;
    eventHandlers.push(subscription);
    eventHandlers.sort((a, b) => a.priority - b.priority);

    logger.debug('Event handler subscribed', { event, id: subscription.id, priority: subscription.priority });
    return subscription.id;
  }

  unsubscribe(event: string, handlerId: string): boolean {
    const eventHandlers = this.handlers.get(event);
    if (!eventHandlers) return false;

    const initialLength = eventHandlers.length;
    const filtered = eventHandlers.filter((h) => h.id !== handlerId);
    this.handlers.set(event, filtered);

    if (filtered.length !== initialLength) {
      logger.debug('Event handler unsubscribed', { event, handlerId });
      return true;
    }
    return false;
  }

  async emit<T = any>(event: string, payload: T): Promise<void> {
    const eventHandlers = this.handlers.get(event);
    if (!eventHandlers || eventHandlers.length === 0) {
      logger.trace('No handlers for event', { event });
      return;
    }

    const handlersToProcess = [...eventHandlers];

    for (const subscription of handlersToProcess) {
      try {
        await subscription.handler(payload);

        if (subscription.once) {
          this.unsubscribe(event, subscription.id);
        }
      } catch (error) {
        logger.error('Event handler error', {
          event,
          handlerId: subscription.id,
          error: error instanceof Error ? error.message : String(error),
        });
      }
    }
  }

  async emitParallel<T = any>(event: string, payload: T): Promise<void> {
    const eventHandlers = this.handlers.get(event);
    if (!eventHandlers || eventHandlers.length === 0) {
      return;
    }

    await Promise.all(
      eventHandlers.map((subscription) =>
        Promise.resolve(subscription.handler(payload)).catch((error: unknown) => {
          logger.error('Event handler error (parallel)', {
            event,
            handlerId: subscription.id,
            error: error instanceof Error ? error.message : String(error),
          });
        })
      )
    );

    const toRemove = eventHandlers.filter((h) => h.once && h.id);
    for (const subscription of toRemove) {
      this.unsubscribe(event, subscription.id);
    }
  }

  getHandlerCount(event?: string): number {
    if (!event) {
      let total = 0;
      for (const handlers of this.handlers.values()) {
        total += handlers.length;
      }
      return total;
    }

    const handlers = this.handlers.get(event);
    return handlers ? handlers.length : 0;
  }

  getEventNames(): string[] {
    return Array.from(this.handlers.keys());
  }

  clearEvent(event: string): void {
    this.handlers.delete(event);
    logger.debug('Cleared all handlers for event', { event });
  }

  clearAll(): void {
    this.handlers.clear();
    this.handlerCounter = 0;
    logger.info('Cleared all event handlers');
  }
}

export const eventBus = EventBus.getInstance();
