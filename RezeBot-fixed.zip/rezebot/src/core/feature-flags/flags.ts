export const ModuleName = {
  MODERATION: 'moderation',
  SECURITY: 'security',
  NATURAL_LANGUAGE: 'natural-language',
  AI: 'ai',
  CURRENCY: 'currency',
  CRYPTO: 'crypto',
  GIFTS: 'gifts',
  MUSIC: 'music',
  GAMES: 'games',
  ECONOMY: 'economy',
  SUPPORT: 'support',
  SCHEDULER: 'scheduler',
  ANALYTICS: 'analytics',
  FAQ: 'faq',
  WELCOME: 'welcome',
  REPORTS: 'reports',
  TOPICS: 'topics',
  REACTIONS: 'reactions',
  PAYMENTS: 'payments',
  MINI_APP: 'mini-app',
  TRANSLATION: 'translation',
  SUMMARIZATION: 'summarization',
  SMART_AUTOMATION: 'smart-automation',
  ANTI_RAID: 'anti-raid',
  ANTI_SPAM: 'anti-spam',
  TICKETS: 'tickets',
  RULES: 'rules',
  FILTERS: 'filters',
  WELCOME_RULES: 'welcome-rules',
  REACTION_ROLES: 'reaction-roles',
  BUSINESS: 'business',
  GIVEAWAY: 'giveaway',
} as const;

export type ModuleName = (typeof ModuleName)[keyof typeof ModuleName];

export const FeatureFlag = {
  MODERATION_BAN: 'moderation.ban',
  MODERATION_KICK: 'moderation.kick',
  MODERATION_MUTE: 'moderation.mute',
  MODERATION_WARN: 'moderation.warn',
  MODERATION_DELETE: 'moderation.delete',
  MODERATION_LOCK: 'moderation.lock',
  MODERATION_ROLES: 'moderation.roles',
  MODERATION_PIN: 'moderation.pin',

  SECURITY_ANTI_SPAM: 'security.anti-spam',
  SECURITY_ANTI_RAID: 'security.anti-raid',
  SECURITY_GUARDIAN: 'security.guardian',
  SECURITY_QUARANTINE: 'security.quarantine',
  SECURITY_REPORTS: 'security.reports',
  SECURITY_TICKETS: 'security.tickets',

  NLP_PERSIAN_NORMALIZE: 'nlp.persian.normalize',
  NLP_PERSIAN_INTENT: 'nlp.persian.intent',
  NLP_PERSIAN_DETECT: 'nlp.persian.detect',
  NLP_PERSIAN_SLANG: 'nlp.persian.slang',

  AI_INTENT_PARSING: 'ai.intent-parsing',
  AI_TRANSLATION: 'ai.translation',
  AI_SUMMARIZATION: 'ai.summarization',
  AI_SMART_AUTOMATION: 'ai.smart-automation',

  ECONOMY_POINTS: 'economy.points',
  ECONOMY_SHOP: 'economy.shop',
  ECONOMY_LEADERBOARD: 'economy.leaderboard',
  ECONOMY_DAILY: 'economy.daily',

  MUSIC_PLAY: 'music.play',
  MUSIC_QUEUE: 'music.queue',
  MUSIC_SKIP: 'music.skip',
  MUSIC_STOP: 'music.stop',

  GAMES_TRIVIA: 'games.trivia',
  GAMES_CARDS: 'games.cards',
  GAMES_GUESS: 'games.guess',

  CURRENCY_CONVERT: 'currency.convert',
  CURRENCY_TRACK: 'currency.track',

  CRYPTO_PRICE: 'crypto.price',
  CRYPTO_WATCH: 'crypto.watch',
  CRYPTO_PORTFOLIO: 'crypto.portfolio',

  GIFTS_SEND: 'gifts.send',
  GIFTS_RECEIVE: 'gifts.receive',

  SCHEDULER_CRON: 'scheduler.cron',
  SCHEDULER_REMINDERS: 'scheduler.reminders',

  SUPPORT_TICKETS: 'support.tickets',
  SUPPORT_QUESTIONNAIRE: 'support.questionnaire',

  FAQ_MANAGE: 'faq.manage',
  FAQ_AUTO: 'faq.auto',

  WELCOME_CUSTOM: 'welcome.custom',
  WELCOME_WELCOME: 'welcome.welcome',

  REPORTS_USER: 'reports.user',
  REPORTS_CHANNEL: 'reports.channel',

  TOPICS_AUTO: 'topics.auto',
  TOPICS_MANAGE: 'topics.manage',

  REACTIONS_CUSTOM: 'reactions.custom',
  REACTIONS_TRACK: 'reactions.track',

  PAYMENTS_DONATE: 'payments.donate',
  PAYMENTS_SUBSCRIPTION: 'payments.subscription',

  MINI_APP_AUTH: 'mini-app.auth',
  MINI_APP_WEBAPP: 'mini-app.webapp',
  MINI_APP_BRIDGE: 'mini-app.bridge',

  TRANSLATION_AUTO: 'ai.translation.auto',
  TRANSLATION_MANUAL: 'ai.translation.manual',

  SUMMARIZATION_CHAT: 'ai.summarization.chat',
  SUMMARIZATION_DAILY: 'ai.summarization.daily',

  SMART_AUTO_MOD: 'ai.smart-automation.auto-moderate',
  SMART_REPLY: 'ai.smart-automation.reply-suggestions',

  ANALYTICS_TRACKING: 'analytics.tracking',
  ANALYTICS_DASHBOARD: 'analytics.dashboard',
  ANALYTICS_REPORTS: 'analytics.reports',

  ANTI_RAID_JOIN: 'security.anti-raid.join',
  ANTI_RAID_VERIFY: 'security.anti-raid.verify',
  ANTI_RAID_CAPTCHA: 'security.anti-raid.captcha',

  RULES_DISPLAY: 'faqs.rules.display',
  RULES_ACCEPT: 'faqs.rules.accept',

  FILTERS_KEYWORD: 'filters.keyword',
  FILTERS_REGEX: 'filters.regex',
  FILTERS_MEDIA: 'filters.media',

  REACTION_ROLES_ASSIGN: 'reactions.roles.assign',

  GIVEAWAY_CREATE: 'payments.giveaway.create',
  GIVEAWAY_RUN: 'payments.giveaway.run',

  WEB_PANEL: 'web.panel',
  WEB_MINI_APP: 'web.mini-app',
  WEB_API: 'web.api',

  WELCOME_RULES: 'welcome.rules',
  REACTION_ROLES: 'reactions.roles',
  BUSINESS: 'business.api',
  GIVEAWAY: 'payments.giveaway',
} as const;

export type FeatureFlag = (typeof FeatureFlag)[keyof typeof FeatureFlag];

export const PROVIDER_REQUIREMENTS = {
  AI_INTENT: 'OPENAI_API_KEY',
  AI_TRANSLATION: 'OPENAI_API_KEY',
  AI_SUMMARIZATION: 'ANTHROPIC_API_KEY',
  AI_SMART_AUTOMATION: 'OPENROUTER_API_KEY',
  MUSIC_SERVICE: 'MT_PROTO_SESSION_STRING',
  CRYPTO_PRICE: 'COINGECKO_API_KEY',
  CURRENCY_CONVERT: 'EXCHANGE_RATE_API_KEY',
  GIFTS_SERVICE: 'KAVENEGAR_API_KEY',
  ANALYTICS_MIXPANEL: 'MIXPANEL_TOKEN',
  ANALYTICS_POSTHOG: 'POSTHOG_API_KEY',
} as const;

export type ProviderRequirement = (typeof PROVIDER_REQUIREMENTS)[keyof typeof PROVIDER_REQUIREMENTS];

export const FeatureStatus = {
  ACTIVE: 'active',
  INACTIVE: 'inactive',
  REQUIRES_PROVIDER: 'requires_provider',
  REQUIRES_MTPROTO: 'requires_mtproto',
  UNSUPPORTED: 'unsupported',
} as const;

export type FeatureStatus = (typeof FeatureStatus)[keyof typeof FeatureStatus];

export interface FeatureFlagDefinition {
  name: FeatureFlag;
  module: ModuleName;
  defaultStatus: FeatureStatus;
  description: string;
  providerEnvKey?: ProviderRequirement;
  dependencies?: FeatureFlag[];
}

export const FEATURE_DEFINITIONS: Record<FeatureFlag, FeatureFlagDefinition> = {
  [FeatureFlag.MODERATION_BAN]: {
    name: FeatureFlag.MODERATION_BAN,
    module: ModuleName.MODERATION,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'Ban users from the chat',
  },
  [FeatureFlag.MODERATION_KICK]: {
    name: FeatureFlag.MODERATION_KICK,
    module: ModuleName.MODERATION,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'Kick users from the chat',
  },
  [FeatureFlag.MODERATION_MUTE]: {
    name: FeatureFlag.MODERATION_MUTE,
    module: ModuleName.MODERATION,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'Mute users in the chat',
  },
  [FeatureFlag.MODERATION_WARN]: {
    name: FeatureFlag.MODERATION_WARN,
    module: ModuleName.MODERATION,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'Warn users in the chat',
  },
  [FeatureFlag.MODERATION_DELETE]: {
    name: FeatureFlag.MODERATION_DELETE,
    module: ModuleName.MODERATION,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'Delete messages',
  },
  [FeatureFlag.MODERATION_LOCK]: {
    name: FeatureFlag.MODERATION_LOCK,
    module: ModuleName.MODERATION,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'Lock/unlock chat',
  },
  [FeatureFlag.MODERATION_ROLES]: {
    name: FeatureFlag.MODERATION_ROLES,
    module: ModuleName.MODERATION,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'Manage custom roles and permissions',
  },
  [FeatureFlag.MODERATION_PIN]: {
    name: FeatureFlag.MODERATION_PIN,
    module: ModuleName.MODERATION,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'Pin/unpin messages',
  },

  [FeatureFlag.SECURITY_ANTI_SPAM]: {
    name: FeatureFlag.SECURITY_ANTI_SPAM,
    module: ModuleName.SECURITY,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'Anti-spam detection and filtering',
  },
  [FeatureFlag.SECURITY_ANTI_RAID]: {
    name: FeatureFlag.SECURITY_ANTI_RAID,
    module: ModuleName.SECURITY,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'Anti-raid protection on new joins',
  },
  [FeatureFlag.SECURITY_GUARDIAN]: {
    name: FeatureFlag.SECURITY_GUARDIAN,
    module: ModuleName.SECURITY,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'Guardian Engine with risk scoring',
  },
  [FeatureFlag.SECURITY_QUARANTINE]: {
    name: FeatureFlag.SECURITY_QUARANTINE,
    module: ModuleName.SECURITY,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'Quarantine suspicious users',
  },
  [FeatureFlag.SECURITY_REPORTS]: {
    name: FeatureFlag.SECURITY_REPORTS,
    module: ModuleName.SECURITY,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'User reporting system',
  },
  [FeatureFlag.SECURITY_TICKETS]: {
    name: FeatureFlag.SECURITY_TICKETS,
    module: ModuleName.SECURITY,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'Support ticket system',
  },

  [FeatureFlag.NLP_PERSIAN_NORMALIZE]: {
    name: FeatureFlag.NLP_PERSIAN_NORMALIZE,
    module: ModuleName.NATURAL_LANGUAGE,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'Persian text normalization (ي→ی, ك→ک, digits, etc.)',
  },
  [FeatureFlag.NLP_PERSIAN_INTENT]: {
    name: FeatureFlag.NLP_PERSIAN_INTENT,
    module: ModuleName.NATURAL_LANGUAGE,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'Persian intent parsing and classification',
  },
  [FeatureFlag.NLP_PERSIAN_DETECT]: {
    name: FeatureFlag.NLP_PERSIAN_DETECT,
    module: ModuleName.NATURAL_LANGUAGE,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'Detect Persian language in messages',
  },
  [FeatureFlag.NLP_PERSIAN_SLANG]: {
    name: FeatureFlag.NLP_PERSIAN_SLANG,
    module: ModuleName.NATURAL_LANGUAGE,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'Handle Persian slang and colloquialisms',
  },

  [FeatureFlag.AI_INTENT_PARSING]: {
    name: FeatureFlag.AI_INTENT_PARSING,
    module: ModuleName.AI,
    defaultStatus: FeatureStatus.REQUIRES_PROVIDER,
    description: 'AI-powered intent parsing',
    providerEnvKey: PROVIDER_REQUIREMENTS.AI_INTENT,
  },
  [FeatureFlag.AI_TRANSLATION]: {
    name: FeatureFlag.AI_TRANSLATION,
    module: ModuleName.AI,
    defaultStatus: FeatureStatus.REQUIRES_PROVIDER,
    description: 'AI-powered translation',
    providerEnvKey: PROVIDER_REQUIREMENTS.AI_TRANSLATION,
  },
  [FeatureFlag.AI_SUMMARIZATION]: {
    name: FeatureFlag.AI_SUMMARIZATION,
    module: ModuleName.AI,
    defaultStatus: FeatureStatus.REQUIRES_PROVIDER,
    description: 'AI-powered summarization',
    providerEnvKey: PROVIDER_REQUIREMENTS.AI_SUMMARIZATION,
  },
  [FeatureFlag.AI_SMART_AUTOMATION]: {
    name: FeatureFlag.AI_SMART_AUTOMATION,
    module: ModuleName.AI,
    defaultStatus: FeatureStatus.REQUIRES_PROVIDER,
    description: 'AI-powered smart automation',
    providerEnvKey: PROVIDER_REQUIREMENTS.AI_SMART_AUTOMATION,
  },

  [FeatureFlag.TRANSLATION_AUTO]: {
    name: FeatureFlag.TRANSLATION_AUTO,
    module: ModuleName.AI,
    defaultStatus: FeatureStatus.REQUIRES_PROVIDER,
    description: 'Automatic translation of messages',
    providerEnvKey: PROVIDER_REQUIREMENTS.AI_TRANSLATION,
  },
  [FeatureFlag.TRANSLATION_MANUAL]: {
    name: FeatureFlag.TRANSLATION_MANUAL,
    module: ModuleName.AI,
    defaultStatus: FeatureStatus.REQUIRES_PROVIDER,
    description: 'Manual translation commands',
    providerEnvKey: PROVIDER_REQUIREMENTS.AI_TRANSLATION,
  },

  [FeatureFlag.SUMMARIZATION_CHAT]: {
    name: FeatureFlag.SUMMARIZATION_CHAT,
    module: ModuleName.AI,
    defaultStatus: FeatureStatus.REQUIRES_PROVIDER,
    description: 'Summarize chat history',
    providerEnvKey: PROVIDER_REQUIREMENTS.AI_SUMMARIZATION,
  },
  [FeatureFlag.SUMMARIZATION_DAILY]: {
    name: FeatureFlag.SUMMARIZATION_DAILY,
    module: ModuleName.AI,
    defaultStatus: FeatureStatus.REQUIRES_PROVIDER,
    description: 'Daily chat summary',
    providerEnvKey: PROVIDER_REQUIREMENTS.AI_SUMMARIZATION,
  },

  [FeatureFlag.SMART_AUTO_MOD]: {
    name: FeatureFlag.SMART_AUTO_MOD,
    module: ModuleName.AI,
    defaultStatus: FeatureStatus.REQUIRES_PROVIDER,
    description: 'Automatic moderation via AI',
    providerEnvKey: PROVIDER_REQUIREMENTS.AI_SMART_AUTOMATION,
  },
  [FeatureFlag.SMART_REPLY]: {
    name: FeatureFlag.SMART_REPLY,
    module: ModuleName.AI,
    defaultStatus: FeatureStatus.REQUIRES_PROVIDER,
    description: 'AI-powered reply suggestions',
    providerEnvKey: PROVIDER_REQUIREMENTS.AI_SMART_AUTOMATION,
  },

  [FeatureFlag.ECONOMY_POINTS]: {
    name: FeatureFlag.ECONOMY_POINTS,
    module: ModuleName.ECONOMY,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'Economy points system',
  },
  [FeatureFlag.ECONOMY_SHOP]: {
    name: FeatureFlag.ECONOMY_SHOP,
    module: ModuleName.ECONOMY,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'Economy shop system',
  },
  [FeatureFlag.ECONOMY_LEADERBOARD]: {
    name: FeatureFlag.ECONOMY_LEADERBOARD,
    module: ModuleName.ECONOMY,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'Economy leaderboard',
  },
  [FeatureFlag.ECONOMY_DAILY]: {
    name: FeatureFlag.ECONOMY_DAILY,
    module: ModuleName.ECONOMY,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'Daily rewards for economy',
  },

  [FeatureFlag.MUSIC_PLAY]: {
    name: FeatureFlag.MUSIC_PLAY,
    module: ModuleName.MUSIC,
    defaultStatus: FeatureStatus.REQUIRES_MTPROTO,
    description: 'Play music in voice chats',
    providerEnvKey: PROVIDER_REQUIREMENTS.MUSIC_SERVICE,
  },
  [FeatureFlag.MUSIC_QUEUE]: {
    name: FeatureFlag.MUSIC_QUEUE,
    module: ModuleName.MUSIC,
    defaultStatus: FeatureStatus.REQUIRES_MTPROTO,
    description: 'Music queue management',
    providerEnvKey: PROVIDER_REQUIREMENTS.MUSIC_SERVICE,
  },
  [FeatureFlag.MUSIC_SKIP]: {
    name: FeatureFlag.MUSIC_SKIP,
    module: ModuleName.MUSIC,
    defaultStatus: FeatureStatus.REQUIRES_MTPROTO,
    description: 'Skip current track',
    providerEnvKey: PROVIDER_REQUIREMENTS.MUSIC_SERVICE,
  },
  [FeatureFlag.MUSIC_STOP]: {
    name: FeatureFlag.MUSIC_STOP,
    module: ModuleName.MUSIC,
    defaultStatus: FeatureStatus.REQUIRES_MTPROTO,
    description: 'Stop playback',
    providerEnvKey: PROVIDER_REQUIREMENTS.MUSIC_SERVICE,
  },

  [FeatureFlag.GAMES_TRIVIA]: {
    name: FeatureFlag.GAMES_TRIVIA,
    module: ModuleName.GAMES,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'Trivia quiz game',
  },
  [FeatureFlag.GAMES_CARDS]: {
    name: FeatureFlag.GAMES_CARDS,
    module: ModuleName.GAMES,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'Card games',
  },
  [FeatureFlag.GAMES_GUESS]: {
    name: FeatureFlag.GAMES_GUESS,
    module: ModuleName.GAMES,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'Number guessing game',
  },

  [FeatureFlag.CURRENCY_CONVERT]: {
    name: FeatureFlag.CURRENCY_CONVERT,
    module: ModuleName.CURRENCY,
    defaultStatus: FeatureStatus.REQUIRES_PROVIDER,
    description: 'Currency conversion',
    providerEnvKey: PROVIDER_REQUIREMENTS.CURRENCY_CONVERT,
  },
  [FeatureFlag.CURRENCY_TRACK]: {
    name: FeatureFlag.CURRENCY_TRACK,
    module: ModuleName.CURRENCY,
    defaultStatus: FeatureStatus.REQUIRES_PROVIDER,
    description: 'Currency price tracking',
    providerEnvKey: PROVIDER_REQUIREMENTS.CURRENCY_CONVERT,
  },

  [FeatureFlag.CRYPTO_PRICE]: {
    name: FeatureFlag.CRYPTO_PRICE,
    module: ModuleName.CRYPTO,
    defaultStatus: FeatureStatus.REQUIRES_PROVIDER,
    description: 'Cryptocurrency price lookup',
    providerEnvKey: PROVIDER_REQUIREMENTS.CRYPTO_PRICE,
  },
  [FeatureFlag.CRYPTO_WATCH]: {
    name: FeatureFlag.CRYPTO_WATCH,
    module: ModuleName.CRYPTO,
    defaultStatus: FeatureStatus.REQUIRES_PROVIDER,
    description: 'Cryptocurrency price alerts',
    providerEnvKey: PROVIDER_REQUIREMENTS.CRYPTO_PRICE,
  },
  [FeatureFlag.CRYPTO_PORTFOLIO]: {
    name: FeatureFlag.CRYPTO_PORTFOLIO,
    module: ModuleName.CRYPTO,
    defaultStatus: FeatureStatus.REQUIRES_PROVIDER,
    description: 'Cryptocurrency portfolio tracking',
    providerEnvKey: PROVIDER_REQUIREMENTS.CRYPTO_PRICE,
  },

  [FeatureFlag.GIFTS_SEND]: {
    name: FeatureFlag.GIFTS_SEND,
    module: ModuleName.GIFTS,
    defaultStatus: FeatureStatus.REQUIRES_PROVIDER,
    description: 'Send gifts to other users',
    providerEnvKey: PROVIDER_REQUIREMENTS.GIFTS_SERVICE,
  },
  [FeatureFlag.GIFTS_RECEIVE]: {
    name: FeatureFlag.GIFTS_RECEIVE,
    module: ModuleName.GIFTS,
    defaultStatus: FeatureStatus.REQUIRES_PROVIDER,
    description: 'Receive gifts from other users',
    providerEnvKey: PROVIDER_REQUIREMENTS.GIFTS_SERVICE,
  },

  [FeatureFlag.SCHEDULER_CRON]: {
    name: FeatureFlag.SCHEDULER_CRON,
    module: ModuleName.SCHEDULER,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'Cron job scheduling',
  },
  [FeatureFlag.SCHEDULER_REMINDERS]: {
    name: FeatureFlag.SCHEDULER_REMINDERS,
    module: ModuleName.SCHEDULER,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'Reminder scheduling',
  },

  [FeatureFlag.SUPPORT_TICKETS]: {
    name: FeatureFlag.SUPPORT_TICKETS,
    module: ModuleName.SUPPORT,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'Support ticket system',
  },
  [FeatureFlag.SUPPORT_QUESTIONNAIRE]: {
    name: FeatureFlag.SUPPORT_QUESTIONNAIRE,
    module: ModuleName.SUPPORT,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'Support questionnaire',
  },

  [FeatureFlag.FAQ_MANAGE]: {
    name: FeatureFlag.FAQ_MANAGE,
    module: ModuleName.FAQ,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'Manage FAQ entries',
  },
  [FeatureFlag.FAQ_AUTO]: {
    name: FeatureFlag.FAQ_AUTO,
    module: ModuleName.FAQ,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'Auto-answer FAQ from messages',
  },

  [FeatureFlag.WELCOME_CUSTOM]: {
    name: FeatureFlag.WELCOME_CUSTOM,
    module: ModuleName.WELCOME,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'Custom welcome messages',
  },
  [FeatureFlag.WELCOME_WELCOME]: {
    name: FeatureFlag.WELCOME_WELCOME,
    module: ModuleName.WELCOME,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'Welcome new users',
  },

  [FeatureFlag.REPORTS_USER]: {
    name: FeatureFlag.REPORTS_USER,
    module: ModuleName.REPORTS,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'User reporting system',
  },
  [FeatureFlag.REPORTS_CHANNEL]: {
    name: FeatureFlag.REPORTS_CHANNEL,
    module: ModuleName.REPORTS,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'Report to channel',
  },

  [FeatureFlag.TOPICS_AUTO]: {
    name: FeatureFlag.TOPICS_AUTO,
    module: ModuleName.TOPICS,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'Auto-create topics',
  },
  [FeatureFlag.TOPICS_MANAGE]: {
    name: FeatureFlag.TOPICS_MANAGE,
    module: ModuleName.TOPICS,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'Manage topics',
  },

  [FeatureFlag.REACTIONS_CUSTOM]: {
    name: FeatureFlag.REACTIONS_CUSTOM,
    module: ModuleName.REACTIONS,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'Custom reaction packs',
  },
  [FeatureFlag.REACTIONS_TRACK]: {
    name: FeatureFlag.REACTIONS_TRACK,
    module: ModuleName.REACTIONS,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'Track message reactions',
  },
  [FeatureFlag.PAYMENTS_DONATE]: {
    name: FeatureFlag.PAYMENTS_DONATE,
    module: ModuleName.PAYMENTS,
    defaultStatus: FeatureStatus.REQUIRES_PROVIDER,
    description: 'Accept donations',
  },
  [FeatureFlag.PAYMENTS_SUBSCRIPTION]: {
    name: FeatureFlag.PAYMENTS_SUBSCRIPTION,
    module: ModuleName.PAYMENTS,
    defaultStatus: FeatureStatus.REQUIRES_PROVIDER,
    description: 'Subscription payments',
  },

  [FeatureFlag.MINI_APP_AUTH]: {
    name: FeatureFlag.MINI_APP_AUTH,
    module: ModuleName.MINI_APP,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'Mini App authentication',
  },
  [FeatureFlag.MINI_APP_WEBAPP]: {
    name: FeatureFlag.MINI_APP_WEBAPP,
    module: ModuleName.MINI_APP,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'Mini App WebApp integration',
  },
  [FeatureFlag.MINI_APP_BRIDGE]: {
    name: FeatureFlag.MINI_APP_BRIDGE,
    module: ModuleName.MINI_APP,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'Bot-to-Mini-App bridge',
  },

  [FeatureFlag.RULES_DISPLAY]: {
    name: FeatureFlag.RULES_DISPLAY,
    module: ModuleName.FAQ,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'Display chat rules',
  },
  [FeatureFlag.RULES_ACCEPT]: {
    name: FeatureFlag.RULES_ACCEPT,
    module: ModuleName.FAQ,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'Accept rules on join',
  },

  [FeatureFlag.FILTERS_KEYWORD]: {
    name: FeatureFlag.FILTERS_KEYWORD,
    module: ModuleName.SECURITY,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'Keyword filtering',
  },
  [FeatureFlag.FILTERS_REGEX]: {
    name: FeatureFlag.FILTERS_REGEX,
    module: ModuleName.SECURITY,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'Regex filtering',
  },
  [FeatureFlag.FILTERS_MEDIA]: {
    name: FeatureFlag.FILTERS_MEDIA,
    module: ModuleName.SECURITY,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'Media filtering',
  },

  [FeatureFlag.REACTION_ROLES_ASSIGN]: {
    name: FeatureFlag.REACTION_ROLES_ASSIGN,
    module: ModuleName.REACTIONS,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'Assign roles via reactions',
  },

  [FeatureFlag.GIVEAWAY_CREATE]: {
    name: FeatureFlag.GIVEAWAY_CREATE,
    module: ModuleName.PAYMENTS,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'Create giveaways',
  },
  [FeatureFlag.GIVEAWAY_RUN]: {
    name: FeatureFlag.GIVEAWAY_RUN,
    module: ModuleName.PAYMENTS,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'Run giveaways',
  },

  [FeatureFlag.WEB_PANEL]: {
    name: FeatureFlag.WEB_PANEL,
    module: ModuleName.MINI_APP,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'Web panel access',
  },
  [FeatureFlag.WEB_MINI_APP]: {
    name: FeatureFlag.WEB_MINI_APP,
    module: ModuleName.MINI_APP,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'Mini App web access',
  },
  [FeatureFlag.WEB_API]: {
    name: FeatureFlag.WEB_API,
    module: ModuleName.MINI_APP,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'Web API access',
  },

  [FeatureFlag.ANALYTICS_TRACKING]: {
    name: FeatureFlag.ANALYTICS_TRACKING,
    module: ModuleName.ANALYTICS,
    defaultStatus: FeatureStatus.REQUIRES_PROVIDER,
    description: 'Analytics tracking',
    providerEnvKey: PROVIDER_REQUIREMENTS.ANALYTICS_MIXPANEL,
  },
  [FeatureFlag.ANALYTICS_DASHBOARD]: {
    name: FeatureFlag.ANALYTICS_DASHBOARD,
    module: ModuleName.ANALYTICS,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'Analytics dashboard',
  },
  [FeatureFlag.ANALYTICS_REPORTS]: {
    name: FeatureFlag.ANALYTICS_REPORTS,
    module: ModuleName.ANALYTICS,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'Analytics reports',
  },

  [FeatureFlag.ANTI_RAID_JOIN]: {
    name: FeatureFlag.ANTI_RAID_JOIN,
    module: ModuleName.SECURITY,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'Anti-raid on new joins',
  },
  [FeatureFlag.ANTI_RAID_VERIFY]: {
    name: FeatureFlag.ANTI_RAID_VERIFY,
    module: ModuleName.SECURITY,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'Verification on join',
  },
  [FeatureFlag.ANTI_RAID_CAPTCHA]: {
    name: FeatureFlag.ANTI_RAID_CAPTCHA,
    module: ModuleName.SECURITY,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'Captcha on join',
  },

  [FeatureFlag.WELCOME_RULES]: {
    name: FeatureFlag.WELCOME_RULES,
    module: ModuleName.WELCOME,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'Welcome with rules prompt',
  },

  [FeatureFlag.REACTION_ROLES]: {
    name: FeatureFlag.REACTION_ROLES,
    module: ModuleName.REACTIONS,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'Reaction-based roles',
  },

  [FeatureFlag.BUSINESS]: {
    name: FeatureFlag.BUSINESS,
    module: ModuleName.MINI_APP,
    defaultStatus: FeatureStatus.UNSUPPORTED,
    description: 'Telegram Business API (unsupported via Bot API)',
  },

  [FeatureFlag.GIVEAWAY]: {
    name: FeatureFlag.GIVEAWAY,
    module: ModuleName.PAYMENTS,
    defaultStatus: FeatureStatus.ACTIVE,
    description: 'Giveaway engine',
  },
} as const;
