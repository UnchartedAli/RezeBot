"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.featureFlags = exports.FeatureFlags = exports.PROVIDER_REQUIREMENTS = exports.FEATURE_DEFINITIONS = void 0;
exports.checkFeatureFlag = checkFeatureFlag;
exports.isFeatureEnabled = isFeatureEnabled;
exports.requireFeature = requireFeature;
const flags_1 = require("./flags");
const flags_2 = require("./flags");
Object.defineProperty(exports, "FEATURE_DEFINITIONS", { enumerable: true, get: function () { return flags_2.FEATURE_DEFINITIONS; } });
const flags_3 = require("./flags");
Object.defineProperty(exports, "PROVIDER_REQUIREMENTS", { enumerable: true, get: function () { return flags_3.PROVIDER_REQUIREMENTS; } });
const config_1 = require("../config");
const logging_1 = require("../logging");
class FeatureFlags {
    static instance;
    logger = logging_1.LoggerProvider.get('FeatureFlags');
    chatOverrides = new Map();
    userOverrides = new Map();
    globalOverrides = new Map();
    constructor() { }
    static getInstance() {
        if (!FeatureFlags.instance) {
            FeatureFlags.instance = new FeatureFlags();
        }
        return FeatureFlags.instance;
    }
    getStatus(flag, options = {}) {
        const def = flags_2.FEATURE_DEFINITIONS[flag];
        if (!def) {
            this.logger.warn(`Unknown feature flag queried: ${flag}`);
            return flags_1.FeatureStatus.UNSUPPORTED;
        }
        if (options.chatId) {
            const chatKey = String(options.chatId);
            const chatFlags = this.chatOverrides.get(chatKey);
            if (chatFlags) {
                const override = chatFlags.get(flag);
                if (override)
                    return override;
            }
        }
        if (options.userId) {
            const userKey = String(options.userId);
            const userFlags = this.userOverrides.get(userKey);
            if (userFlags) {
                const override = userFlags.get(flag);
                if (override)
                    return override;
            }
        }
        const globalOverride = this.globalOverrides.get(flag);
        if (globalOverride)
            return globalOverride;
        if (def.defaultStatus === flags_1.FeatureStatus.REQUIRES_PROVIDER && !options.skipProviderCheck) {
            if (def.providerEnvKey && !this.isProviderAvailable(def.providerEnvKey)) {
                return flags_1.FeatureStatus.REQUIRES_PROVIDER;
            }
        }
        return def.defaultStatus;
    }
    isEnabled(flag, options = {}) {
        const status = this.getStatus(flag, options);
        return status === flags_1.FeatureStatus.ACTIVE;
    }
    isModuleEnabled(module, options = {}) {
        const flagsForModule = Object.values(flags_2.FEATURE_DEFINITIONS).filter((def) => def.module === module);
        return flagsForModule.some((def) => this.isEnabled(def.name, options));
    }
    isProviderAvailable(envKey) {
        const config = (0, config_1.getConfig)();
        const value = config[envKey];
        return Boolean(value && value !== '');
    }
    setFlag(flag, status, options = {}) {
        if (options.chatId) {
            const chatKey = String(options.chatId);
            if (!this.chatOverrides.has(chatKey)) {
                this.chatOverrides.set(chatKey, new Map());
            }
            this.chatOverrides.get(chatKey).set(flag, status);
        }
        else if (options.userId) {
            const userKey = String(options.userId);
            if (!this.userOverrides.has(userKey)) {
                this.userOverrides.set(userKey, new Map());
            }
            this.userOverrides.get(userKey).set(flag, status);
        }
        else {
            this.globalOverrides.set(flag, status);
        }
        this.logger.info(`Feature flag updated: ${flag} → ${status}`, { flag, status, options });
    }
    enable(flag, options = {}) {
        this.setFlag(flag, flags_1.FeatureStatus.ACTIVE, options);
    }
    disable(flag, options = {}) {
        this.setFlag(flag, flags_1.FeatureStatus.INACTIVE, options);
    }
    getFlagDefinition(flag) {
        return flags_2.FEATURE_DEFINITIONS[flag];
    }
    getAllFlags(options = {}) {
        return Object.values(flags_2.FEATURE_DEFINITIONS).map((def) => ({
            flag: def.name,
            status: this.getStatus(def.name, options),
            definition: def,
        }));
    }
    getModuleFlags(module) {
        return Object.values(flags_2.FEATURE_DEFINITIONS)
            .filter((def) => def.module === module)
            .map((def) => def.name);
    }
    getDisabledFlags(options = {}) {
        return this.getAllFlags(options)
            .filter(({ status }) => status !== flags_1.FeatureStatus.ACTIVE)
            .map(({ flag }) => flag);
    }
    getFlagsRequiringProvider(options = {}) {
        return this.getAllFlags(options)
            .filter(({ status }) => status === flags_1.FeatureStatus.REQUIRES_PROVIDER)
            .map(({ flag }) => flag);
    }
    getFlagsRequiringMtproto(options = {}) {
        return this.getAllFlags(options)
            .filter(({ status }) => status === flags_1.FeatureStatus.REQUIRES_MTPROTO)
            .map(({ flag }) => flag);
    }
    clearChatOverrides(chatId) {
        this.chatOverrides.delete(String(chatId));
    }
    clearUserOverrides(userId) {
        this.userOverrides.delete(String(userId));
    }
    clearGlobalOverrides() {
        this.globalOverrides.clear();
    }
    clearAll() {
        this.chatOverrides.clear();
        this.userOverrides.clear();
        this.globalOverrides.clear();
    }
}
exports.FeatureFlags = FeatureFlags;
exports.featureFlags = FeatureFlags.getInstance();
function checkFeatureFlag(flag, options = {}) {
    return FeatureFlags.getInstance().getStatus(flag, options);
}
function isFeatureEnabled(flag, options = {}) {
    return FeatureFlags.getInstance().isEnabled(flag, options);
}
function requireFeature(flag, options = {}) {
    const status = checkFeatureFlag(flag, options);
    if (status !== flags_1.FeatureStatus.ACTIVE) {
        const { FeatureDisabledError } = require('../errors');
        throw new FeatureDisabledError(`Feature '${flag}' is not available (status: ${status})`, { flag, status });
    }
}
//# sourceMappingURL=FeatureFlags.js.map