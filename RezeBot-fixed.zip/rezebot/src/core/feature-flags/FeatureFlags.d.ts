import { FeatureStatus } from './flags';
import { FeatureFlag } from './flags';
import { ModuleName } from './flags';
import { FeatureFlagDefinition } from './flags';
import { FEATURE_DEFINITIONS } from './flags';
import { PROVIDER_REQUIREMENTS } from './flags';
import type { ProviderRequirement } from './flags';
export type { FeatureFlag, ModuleName, FeatureStatus, FeatureFlagDefinition, ProviderRequirement };
export { FEATURE_DEFINITIONS, PROVIDER_REQUIREMENTS };
export interface FlagCheckOptions {
    chatId?: number | string;
    userId?: number | string;
    module?: ModuleName;
    skipProviderCheck?: boolean;
}
export declare class FeatureFlags {
    private static instance;
    private logger;
    private readonly chatOverrides;
    private readonly userOverrides;
    private readonly globalOverrides;
    private constructor();
    static getInstance(): FeatureFlags;
    getStatus(flag: FeatureFlag, options?: FlagCheckOptions): FeatureStatus;
    isEnabled(flag: FeatureFlag, options?: FlagCheckOptions): boolean;
    isModuleEnabled(module: ModuleName, options?: FlagCheckOptions): boolean;
    private isProviderAvailable;
    setFlag(flag: FeatureFlag, status: FeatureStatus, options?: {
        chatId?: number | string;
        userId?: number | string;
    }): void;
    enable(flag: FeatureFlag, options?: {
        chatId?: number | string;
        userId?: number | string;
    }): void;
    disable(flag: FeatureFlag, options?: {
        chatId?: number | string;
        userId?: number | string;
    }): void;
    getFlagDefinition(flag: FeatureFlag): FeatureFlagDefinition | undefined;
    getAllFlags(options?: FlagCheckOptions): Array<{
        flag: FeatureFlag;
        status: FeatureStatus;
        definition: FeatureFlagDefinition;
    }>;
    getModuleFlags(module: ModuleName): FeatureFlag[];
    getDisabledFlags(options?: FlagCheckOptions): FeatureFlag[];
    getFlagsRequiringProvider(options?: FlagCheckOptions): FeatureFlag[];
    getFlagsRequiringMtproto(options?: FlagCheckOptions): FeatureFlag[];
    clearChatOverrides(chatId: number | string): void;
    clearUserOverrides(userId: number | string): void;
    clearGlobalOverrides(): void;
    clearAll(): void;
}
export declare const featureFlags: FeatureFlags;
export declare function checkFeatureFlag(flag: FeatureFlag, options?: FlagCheckOptions): FeatureStatus;
export declare function isFeatureEnabled(flag: FeatureFlag, options?: FlagCheckOptions): boolean;
export declare function requireFeature(flag: FeatureFlag, options?: FlagCheckOptions): void;
//# sourceMappingURL=FeatureFlags.d.ts.map