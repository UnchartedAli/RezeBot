import { FeatureStatus } from './flags';
import { FeatureFlag } from './flags';
import { ModuleName } from './flags';
import { FeatureFlagDefinition } from './flags';
import { FEATURE_DEFINITIONS } from './flags';
import { PROVIDER_REQUIREMENTS } from './flags';
import type { ProviderRequirement } from './flags';
import { getConfig } from '../config';
import { LoggerProvider } from '../logging';

export type { FeatureFlag, ModuleName, FeatureStatus, FeatureFlagDefinition, ProviderRequirement };
export { FEATURE_DEFINITIONS, PROVIDER_REQUIREMENTS };

export interface FlagCheckOptions {
  chatId?: number | string;
  userId?: number | string;
  module?: ModuleName;
  skipProviderCheck?: boolean;
}

export class FeatureFlags {
  private static instance: FeatureFlags;
  private logger = LoggerProvider.get('FeatureFlags');

  private readonly chatOverrides = new Map<string, Map<FeatureFlag, FeatureStatus>>();
  private readonly userOverrides = new Map<string, Map<FeatureFlag, FeatureStatus>>();
  private readonly globalOverrides = new Map<FeatureFlag, FeatureStatus>();

  private constructor() {}

  static getInstance(): FeatureFlags {
    if (!FeatureFlags.instance) {
      FeatureFlags.instance = new FeatureFlags();
    }
    return FeatureFlags.instance;
  }

  getStatus(flag: FeatureFlag, options: FlagCheckOptions = {}): FeatureStatus {
    const def = FEATURE_DEFINITIONS[flag];
    if (!def) {
      this.logger.warn(`Unknown feature flag queried: ${flag}`);
      return FeatureStatus.UNSUPPORTED;
    }

    if (options.chatId) {
      const chatKey = String(options.chatId);
      const chatFlags = this.chatOverrides.get(chatKey);
      if (chatFlags) {
        const override = chatFlags.get(flag);
        if (override) return override;
      }
    }

    if (options.userId) {
      const userKey = String(options.userId);
      const userFlags = this.userOverrides.get(userKey);
      if (userFlags) {
        const override = userFlags.get(flag);
        if (override) return override;
      }
    }

    const globalOverride = this.globalOverrides.get(flag);
    if (globalOverride) return globalOverride;

    if (def.defaultStatus === FeatureStatus.REQUIRES_PROVIDER && !options.skipProviderCheck) {
      if (def.providerEnvKey && !this.isProviderAvailable(def.providerEnvKey)) {
        return FeatureStatus.REQUIRES_PROVIDER;
      }
    }

    return def.defaultStatus;
  }

  isEnabled(flag: FeatureFlag, options: FlagCheckOptions = {}): boolean {
    const status = this.getStatus(flag, options);
    return status === FeatureStatus.ACTIVE;
  }

  isModuleEnabled(module: ModuleName, options: FlagCheckOptions = {}): boolean {
    const flagsForModule = Object.values(FEATURE_DEFINITIONS).filter(
      (def) => def.module === module
    );

    return flagsForModule.some((def) => this.isEnabled(def.name, options));
  }

  private isProviderAvailable(envKey: ProviderRequirement): boolean {
    const config = getConfig();
    const value = config[envKey as keyof typeof config];
    return Boolean(value && value !== '');
  }

  setFlag(
    flag: FeatureFlag,
    status: FeatureStatus,
    options: { chatId?: number | string; userId?: number | string } = {}
  ): void {
    if (options.chatId) {
      const chatKey = String(options.chatId);
      if (!this.chatOverrides.has(chatKey)) {
        this.chatOverrides.set(chatKey, new Map());
      }
      this.chatOverrides.get(chatKey)!.set(flag, status);
    } else if (options.userId) {
      const userKey = String(options.userId);
      if (!this.userOverrides.has(userKey)) {
        this.userOverrides.set(userKey, new Map());
      }
      this.userOverrides.get(userKey)!.set(flag, status);
    } else {
      this.globalOverrides.set(flag, status);
    }

    this.logger.info(`Feature flag updated: ${flag} → ${status}`, { flag, status, options });
  }

  enable(flag: FeatureFlag, options: { chatId?: number | string; userId?: number | string } = {}): void {
    this.setFlag(flag, FeatureStatus.ACTIVE, options);
  }

  disable(flag: FeatureFlag, options: { chatId?: number | string; userId?: number | string } = {}): void {
    this.setFlag(flag, FeatureStatus.INACTIVE, options);
  }

  getFlagDefinition(flag: FeatureFlag): FeatureFlagDefinition | undefined {
    return FEATURE_DEFINITIONS[flag];
  }

  getAllFlags(options: FlagCheckOptions = {}): Array<{
    flag: FeatureFlag;
    status: FeatureStatus;
    definition: FeatureFlagDefinition;
  }> {
    return Object.values(FEATURE_DEFINITIONS).map((def) => ({
      flag: def.name,
      status: this.getStatus(def.name, options),
      definition: def,
    }));
  }

  getModuleFlags(module: ModuleName): FeatureFlag[] {
    return Object.values(FEATURE_DEFINITIONS)
      .filter((def) => def.module === module)
      .map((def) => def.name);
  }

  getDisabledFlags(options: FlagCheckOptions = {}): FeatureFlag[] {
    return this.getAllFlags(options)
      .filter(({ status }) => status !== FeatureStatus.ACTIVE)
      .map(({ flag }) => flag);
  }

  getFlagsRequiringProvider(options: FlagCheckOptions = {}): FeatureFlag[] {
    return this.getAllFlags(options)
      .filter(({ status }) => status === FeatureStatus.REQUIRES_PROVIDER)
      .map(({ flag }) => flag);
  }

  getFlagsRequiringMtproto(options: FlagCheckOptions = {}): FeatureFlag[] {
    return this.getAllFlags(options)
      .filter(({ status }) => status === FeatureStatus.REQUIRES_MTPROTO)
      .map(({ flag }) => flag);
  }

  clearChatOverrides(chatId: number | string): void {
    this.chatOverrides.delete(String(chatId));
  }

  clearUserOverrides(userId: number | string): void {
    this.userOverrides.delete(String(userId));
  }

  clearGlobalOverrides(): void {
    this.globalOverrides.clear();
  }

  clearAll(): void {
    this.chatOverrides.clear();
    this.userOverrides.clear();
    this.globalOverrides.clear();
  }
}

export const featureFlags = FeatureFlags.getInstance();

export function checkFeatureFlag(
  flag: FeatureFlag,
  options: FlagCheckOptions = {}
): FeatureStatus {
  return FeatureFlags.getInstance().getStatus(flag, options);
}

export function isFeatureEnabled(
  flag: FeatureFlag,
  options: FlagCheckOptions = {}
): boolean {
  return FeatureFlags.getInstance().isEnabled(flag, options);
}

export function requireFeature(
  flag: FeatureFlag,
  options: FlagCheckOptions = {}
): void {
  const status = checkFeatureFlag(flag, options);
  if (status !== FeatureStatus.ACTIVE) {
    const { FeatureDisabledError } = require('../errors');
    throw new FeatureDisabledError(
      `Feature '${flag}' is not available (status: ${status})`,
      { flag, status }
    );
  }
}
